'''
Lina Gao (linafreee@163.com)
'''

import time
import warnings
import numpy as np
import scipy.io as io
import torch
import torch.nn as nn
from collections import defaultdict
import torch.optim as optim
import json
from torch.autograd import Variable
# from torchvision.models import AlexNet
# from torchviz import make_dot

import sys
import objgraph
import random

torch.set_printoptions(profile="full")

class Logger(object):
    def __init__(self, filename='default.log', stream=sys.stdout):
        self.terminal = stream
        self.log = open(filename, 'w')

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass

# TODO: get data
class data_preparation():

    def __init__(self):
        pass

    def get_trust_data(self,trust_data):
        self.dic_trust_users=defaultdict(set)  # for aggregation;每个用户信任的用户
        self.dic_trusted_users=defaultdict(set) # for diffusion；每个用户被哪些用户信任
        with open(trust_data, 'r') as infile:
            for line in infile.readlines():
                self.trustor, self.trustee, _= line.strip().split(',')
                self.dic_trust_users[self.trustor].add(self.trustee)
                self.dic_trusted_users[self.trustee].add(self.trustor)
        return self.dic_trust_users,self.dic_trusted_users

    def get_agg123_allData(self):
        self.dic_iti = defaultdict(set)  # for agg2；iti
        with open(path + 'timestamp_metapath/iti.txt', 'r') as infile:
            for line in infile.readlines():
                self.item1, self.item2, _ = line.strip().split('	')
                self.dic_iti[self.item1].add(self.item2)
                self.dic_iti[self.item2].add(self.item1)
        return self.dic_iti

    def get_agg123_timeData(self):
        self.dic_allTime = {}

        '''
        #TODO: for Ciao1
        timestamp_list = ['2000', '2001', '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010',
                          '2011', '2012', '2013']
        for timestamp_name in timestamp_list:
        '''

        #TODO: for Lastfm1
        for timestamp_name in range(17):

            self.dic_thisTime={}
            # self.metapaths = ['ui', 'iu', 'uiu', 'uitiu', 'iui']
            self.dic_ui = defaultdict(set)  # for agg1;ui
            self.dic_iu = defaultdict(set)  # for agg1；iu
            self.dic_uiu = defaultdict(set)  # for agg2;uiu
            self.dic_iui = defaultdict(set) # for agg2；iui
            self.dic_uitiu = defaultdict(set)  # for agg3；uitiu
            self.arr_itemType = np.zeros((num_items, num_types))
            self.one_arr_mask=np.zeros((num_users,num_items))
            # with open(path+'timestamp_movie_ratings/'+str(timestamp_name)+'.txt', 'r') as infile:  # for Ciao2
            with open(path + 'timestamp_user_taggedartists/' + str(timestamp_name) + '.txt', 'r') as infile:  # for Lastfm2
                for line in infile.readlines():
                    self.user, self.item,self.type,_,_= line.strip().split(',')
                    self.dic_ui[self.user].add(self.item)
                    self.dic_iu[self.item].add(self.user)
                    # self.arr_itemType[int(self.item)][int(self.type)-1] = 1 # for Ciao3
                    self.arr_itemType[int(self.item)][int(self.type)] = 1  # for Lastfm3
                    self.one_arr_mask[int(self.user)][int(self.item)]=1
            with open(path+'timestamp_metapath/'+str(timestamp_name)+'_uiu.txt', 'r') as infile:
                for line in infile.readlines():
                    self.user1, self.user2, _= line.strip().split('	')
                    self.dic_uiu[self.user1].add(self.user2)
                    self.dic_uiu[self.user2].add(self.user1)
            with open(path+'timestamp_metapath/'+str(timestamp_name)+'_iui.txt', 'r') as infile:
                for line in infile.readlines():
                    self.item1, self.item2, _= line.strip().split('	')
                    self.dic_iui[self.item1].add(self.item2)
                    self.dic_iui[self.item2].add(self.item1)
            with open(path+'timestamp_metapath/'+str(timestamp_name)+'_uitiu.txt', 'r') as infile:
                for line in infile.readlines():
                    self.user1, self.user2, _= line.strip().split('	')
                    self.dic_uitiu[self.user1].add(self.user2)
                    self.dic_uitiu[self.user2].add(self.user1)
            self.dic_thisTime={'dic_ui':self.dic_ui,'dic_iu':self.dic_iu,'dic_uiu':self.dic_uiu,'dic_iui':self.dic_iui,
                               'dic_uitiu':self.dic_uitiu,'arr_itemType':self.arr_itemType,'one_arr_mask':self.one_arr_mask}
            # self.dic_allTime[str(int(timestamp_name)-2000)]=self.dic_thisTime # for Ciao4
            self.dic_allTime[str(timestamp_name)] = self.dic_thisTime  # for Lastfm4
        return self.dic_allTime

class UserUserGraph(nn.Module):
    # diffusion: user embedding;user_type_pre
    # aggregation: user embedding;user_type_pre
    def __init__(self):
        super(UserUserGraph, self).__init__()

        self.params = nn.ParameterDict({'W_AggUserRec': nn.Parameter(torch.rand(embedding_dimension, embedding_dimension)),'W_AggUserDep': nn.Parameter(torch.rand(embedding_dimension, embedding_dimension)), 'W_DiffUserRec': nn.Parameter(torch.rand(embedding_dimension, embedding_dimension)),'W_DiffUserDep': nn.Parameter(torch.rand(embedding_dimension, embedding_dimension)),'W_agg': nn.Parameter(torch.rand(1,1)),'W_agg_u': nn.Parameter(torch.rand(1,1)),'W_agg_pre': nn.Parameter(torch.rand(1,1)),'W_diff_u': nn.Parameter(torch.rand(1,1)),'W_diff_pre': nn.Parameter(torch.rand(1,1)),'W_uab': nn.Parameter(torch.rand(1,1)),'W_uad': nn.Parameter(torch.rand(1,1)),'W_udb': nn.Parameter(torch.rand(1,1)),'W_udd': nn.Parameter(torch.rand(1,1)),'W_AggTypeRec': nn.Parameter(torch.rand(num_types, num_types)),'W_AggTypeDep': nn.Parameter(torch.rand(num_types, num_types)),'W_DiffTypeRec': nn.Parameter(torch.rand(num_types, num_types)),'W_DiffTypeDep': nn.Parameter(torch.rand(num_types, num_types)),'W_agg_utp': nn.Parameter(torch.rand(1,1)),'W_pab': nn.Parameter(torch.rand(1,1)),'W_pad': nn.Parameter(torch.rand(1,1)),'W_pdb': nn.Parameter(torch.rand(1,1)),'W_pdd': nn.Parameter(torch.rand(1,1))})

    def forward(self,userEmbedding,userTypePre):

        self.userEmbedding_agg,self.userTypePre_agg=self.aggregation_diffusion_user(userEmbedding,userTypePre,'aggregation')
        self.userEmbedding_diff, self.userTypePre_diff = self.aggregation_diffusion_user(userEmbedding,userTypePre, 'diffusion')

        self.userEmbedding = self.userEmbedding_agg * self.params['W_agg'] + self.userEmbedding_diff * (1 - self.params['W_agg'])
        self.userTypePre = self.userTypePre_agg * self.params['W_agg_utp'] + self.userTypePre_diff * (1 - self.params['W_agg_utp'])

        return self.userEmbedding,self.userTypePre

    def aggregation_diffusion_user(self,updvector,updvectorPre,type_name):

        self.updvector,self.updvectorPre,self.UUG_agg_queryUser = updvector,updvectorPre,[int(i) for i in range(num_users)] # store update users - list
        self.array1=torch.zeros(num_users,num_users)  # record  the friend relations in the first layer
        self.array2 = torch.zeros(num_users, num_users) # record  the friend relations in the second layer
        self.array3 = torch.zeros(num_users, num_users)  # record  the friend relations in the third layer
        self.array4 = torch.zeros(num_users, num_users)  # record  the friend relations in the forth layer

        # TODO: multi-layer
        for l in range(1, level + 1): # layer

            self.li_aggquery=[] #user
            self.L_List = [] # friend; sum
            self.L_aggkey = [] # friend

            # TODO: initialization for UUG_agg_queryUser and UUG_agg_queryUserNext
            if l!=1:  #UUG_agg_queryUser
                self.UUG_agg_queryUser=self.UUG_agg_queryUserNext
                del self.UUG_agg_queryUserNext
            self.UUG_agg_queryUserNext = []  # store the friends - list

            # TODO: generate friend vector in each layer
            for k_user in self.UUG_agg_queryUser: # user; int

                # find friends
                if type_name =='aggregation':
                    self.UUG_agg_keyUser=dic_trust_users[str(k_user)] # friends for one user
                else:
                    self.UUG_agg_keyUser = dic_trusted_users[str(k_user)]
                self.li_aggkey = [int(i) for i in self.UUG_agg_keyUser]  # friends for one user - int
                del self.UUG_agg_keyUser
                self.UUG_agg_queryUserNext.extend(self.li_aggkey) # friends for all user - int

                if len(self.li_aggkey) == 0:
                    continue

                # record friend
                if l==1:
                    for i in self.li_aggkey:
                        self.array1[k_user][i] = 1
                elif l==2:
                    for i in self.li_aggkey:
                        self.array2[k_user][i] = 1
                elif l==3:
                    for i in self.li_aggkey:
                        self.array3[k_user][i] = 1
                else:
                    for i in self.li_aggkey:
                        self.array4[k_user][i] = 1

                # friend vector
                self.li_aggquery.append(k_user) # store all users that have friends - list
                self.Key=torch.index_select(self.updvector, 0, torch.tensor(self.li_aggkey)) # friend vector
                self.KeyPre = torch.index_select(self.updvectorPre, 0, torch.tensor(self.li_aggkey))

                if len(self.li_aggquery)==1:
                    self.L_Key=self.Key
                    self.L_KeyPre=self.KeyPre
                    self.L_List=[len(self.li_aggkey)]
                    self.L_aggkey = self.li_aggkey
                else:
                    self.L_Key = torch.cat((self.L_Key,self.Key),dim=0) # friend vectors for all users
                    self.L_KeyPre = torch.cat((self.L_KeyPre,self.KeyPre),dim=0)
                    self.L_List.append(len(self.li_aggkey)) #store the number of friends for each user
                    self.L_aggkey.extend(self.li_aggkey) #store all friends for each user; list
                del self.li_aggkey
                del self.Key
                del self.KeyPre

            # TODO: generate user vector
            self.li_aggquery=[int(i) for i in self.li_aggquery]
            self.query_vector=torch.index_select(self.updvector, 0, torch.tensor(self.li_aggquery)) # original users vectors for all users
            self.query_vectorPre = torch.index_select(self.updvectorPre , 0, torch.tensor(self.li_aggquery))

            # TODO: updvector-breadth
            self.updvector_bre= self.recursion_InfluenceStrength(self.query_vector, self.L_Key, self.li_aggquery,self.L_List, self.L_aggkey,self.updvector,                'embedding',type_name)
            self.updvectorPre_bre= self.recursion_InfluenceStrength(self.query_vectorPre, self.L_KeyPre, self.li_aggquery,self.L_List, self.L_aggkey,                        self.updvectorPre, 'preference',type_name)

            # TODO: generate the user list, friend count, friend list of previous layer for depth
            if l==1:
                self.li_aggquery0 = self.li_aggquery # store the users update for aggregation
                self.li_aggquery0sum = self.L_List  # store the number of friends  for each user
                self.li_aggquery0allNext=self.L_aggkey # store all friends  for each user
                self.attentionIn=torch.zeros(len(self.L_aggkey),1) # store the attention of users in the last layer
                self.attentionInPre = torch.zeros(len(self.L_aggkey), 1)

            else:
                del self.li_aggquery0sum
                del self.attentionIn
                del self.attentionInPre

                # generate the friend count, friend list of previous layer for depth
                self.li_aggquery0all=self.li_aggquery0allNext # store all friends  for each user
                self.de_all=self.li_aggquery0all # copy for delete
                self.li_aggquery0sum = self.li_aggquery0sumNext # store the number of friends  for each user
                self.de_sum=self.li_aggquery0sum # copy for delete
                self.attentionIn = self.attentionOut
                self.attentionInPre = self.attentionOutPre

                del self.attentionOut
                del self.attentionOutPre
                del self.li_aggquery0sumNext
                del self.li_aggquery0allNext

                if l==2:
                    self.array_sum=self.array2.sum(1)  #[*,1]; sum for each row; 2->3
                if l==3:
                    self.array_sum=self.array3.sum(1)  #[*,1]; sum for each row; 3->4
                if l==4:
                    self.array_sum=self.array4.sum(1)  #[*,1]; sum for each row; 4->5

                # delete the li_aggquery0sum, li_aggquery0all and attentionIn
                for i in range(self.array_sum.shape[0]): # user; the current layer
                    if self.array_sum[i]==0: # find the user who has zero friend

                        # obtain the index for delete
                        self.de_index = [jj for jj, x in enumerate(self.li_aggquery0all) if x == i]

                        # delete the li_aggquery0sum->de_sum
                        startk=0
                        for index1 in range(len(self.li_aggquery0sum)):
                            endk=startk+self.li_aggquery0sum[index1]
                            for index2 in self.de_index:
                                if startk<=index2<endk: # sum-1++
                                    self.de_sum[index1]=self.de_sum[index1]-1
                            startk=endk

                        # delete the li_aggquery0all and attentionIn
                        for j in range(len(self.li_aggquery0all)):
                            if i in self.de_all:
                                self.ind=self.de_all.index(i)
                                self.de_all.remove(i)
                                self.attentionIn = torch.cat((self.attentionIn[0:self.ind], self.attentionIn[self.ind + 1:]), dim=0)
                                self.attentionInPre = torch.cat((self.attentionInPre[0:self.ind], self.attentionInPre[self.ind + 1:]), dim=0)

                # abnormal detection
                for i in range(len(self.li_aggquery0sum)):
                    if self.de_sum[i]<0: # find the user who has zero friend
                        print('wrong------------------------------------------------------------------------------------------')

                # delete the de_sum and li_aggquery0
                for i in range(len(self.li_aggquery0sum)):
                    if 0 in self.de_sum:
                        ind = self.de_sum.index(0)
                        self.de_sum.remove(0)
                        self.li_aggquery0.remove(self.li_aggquery0[ind])

                self.li_aggquery0allNext=self.L_aggkey
                self.li_aggquery0sum=self.de_sum

            # assert len(self.li_aggquery0) == len(self.li_aggquery0sum)

            # TODO: assert
            total=0
            for i in range(len(self.li_aggquery0sum)):
                total += self.li_aggquery0sum[i]
            # print('total:', total)
            #
            # print('layer:',l,'li_aggquery:',len(self.li_aggquery),'L_List:',len(self.L_List),'L_aggkey:',len(self.L_aggkey),'li_aggquery0:',len(self.li_aggquery0),               'li_aggquery0sum:',total,'len(li_aggquery0sum):',len(self.li_aggquery0sum))

            # TODO: updvector-depth
            self.updvector_dep, self.attentionOut,self.li_aggquery0sumNext = self.depth_InfluenceStrength(self.query_vector, self.L_Key, self.L_List,                     self.li_aggquery0, self.li_aggquery0sum,self.L_aggkey,self.updvector,self.attentionIn,l, 'embedding',type_name)
            self.updvectorPre_dep,self.attentionOutPre,self.li_aggquery0sumNext = self.depth_InfluenceStrength(self.query_vectorPre, self.L_KeyPre,                  self.L_List, self.li_aggquery0, self.li_aggquery0sum,self.L_aggkey,self.updvectorPre, self.attentionInPre,l,  'preference',type_name)

            # TODO: final
            if type_name=='aggregation':
                self.updvector = self.updvector_bre * self.params['W_agg_u'] + self.updvector_dep * ( 1 - self.params['W_agg_u'])
                self.updvectorPre = self.updvectorPre_bre * self.params['W_agg_pre'] + self.updvectorPre_dep * (1 - self.params['W_agg_pre'])
            else:
                self.updvector = self.updvector_bre * self.params['W_diff_u'] + self.updvector_dep * (1 - self.params['W_diff_u'])
                self.updvectorPre = self.updvectorPre_bre * self.params['W_diff_pre'] + self.updvectorPre_dep * (
                1 - self.params['W_diff_pre'])

            del self.UUG_agg_queryUser
            del self.li_aggquery
            del self.L_List
            del self.L_aggkey

        del self.updvector_bre
        del self.updvector_dep
        del self.updvectorPre_bre
        del self.updvectorPre_dep

        del self.array1
        del self.array2
        del self.UUG_agg_queryUserNext
        del self.li_aggquery0
        try:
            del self.de_sum
        except:
            pass

        try:
            del self.de_index
        except:
            pass

        del self.query_vector
        del self.L_Key
        del self.query_vectorPre
        del self.L_KeyPre

        del self.attentionIn
        del self.attentionInPre
        del self.li_aggquery0sumNext
        del self.li_aggquery0sum

        return self.updvector,self.updvectorPre


    def recursion_InfluenceStrength(self,query_vector,L_Key,li_aggquery,L_list,L_aggkey,vector,updname,type_name):

        # Attention;query,key1,key2,...,keyn,value1,value2,...,valuen;key=value
        # query-q: pre of changed user;key-k: pre of users who trust the changed user;value=key-v
        # hidden_dim=num_items
        # General--align(q, k) = q*W_a*k=[1,hidden_dim]*[hidden_dim,hidden_dim]*[hidden_dim,1]=[1]
        # General_all--align(q, K) = q*W_a*k=[1,hidden_dim]*[hidden_dim,hidden_dim]*[hidden_dim,len(key_list)]=[1,len(key_list)]
        # ×align(q, K) = v^T * tanh(W*[q:k]=[1,hidden_dim]*tanh([hidden_dim,embed_dim]*[embed_dim,rq_num]+[hidden_dim,embed_dim]*[embed_dim,rq_num])
        # ×align(q, K) = v^T * tanh(W*q+U*k)=[1,hidden_dim]*tanh([hidden_dim,embed_dim]*[embed_dim,rq_num]+[hidden_dim,embed_dim]*[embed_dim,rq_num])
        # attention = softmax(align)=[1,num_items]*[len(key_list),num_items]*[num_items,len(key_list)]=[1,len(key_list)]
        # new_pre=attention*v=[1,len(key_list)]*[len(key_list),item_dim]*

        # General
        if updname=='embedding' and type_name =='aggregation':
            self.W=self.params['W_AggUserRec']
            self.W1=self.params['W_uab']
            d = embedding_dimension
        elif updname=='preference' and type_name =='aggregation':
            self.W = self.params['W_AggTypeRec']
            self.W1 = self.params['W_pab']
            d = num_types
        elif updname=='embedding' and type_name =='diffusion':
            self.W=self.params['W_DiffUserRec']
            self.W1=self.params['W_udb']
            d = embedding_dimension
        elif updname=='preference' and type_name =='diffusion':
            self.W = self.params['W_DiffTypeRec']
            self.W1 = self.params['W_pdb']
            d = num_types

        self.vector_final=vector.clone()

        self.align1 = torch.mm(query_vector, self.W) # [m,d]*[d,d]=[m,d]
        m = nn.Softmax(dim=0)

        # TODO: obtain the attention of user to the friends
        start = 0
        end = 0
        for i in range(len(L_list)):
            end = end + L_list[i]
            self.align=torch.mm(self.align1[i].reshape(1,d),L_Key[start:end, ].t()) # [1,len(key_list)]=[1,d]*[d,len(key_list)]
            self.attention = m(self.align.reshape(L_list[i], 1)) # [len(key_list),1]
            self.updvector_one = ((self.attention * L_Key[start:end, ]).sum(0)).reshape(
                1, d) # [len(key_list),d]->[1,d]; sum according to the column
            if start == 0:
                self.L_attention = self.attention
                self.updvector_all = self.updvector_one
            else:
                self.L_attention = torch.cat((self.L_attention, self.attention), 0) #[mlen(key_list),1]; for diffusion
                self.updvector_all = torch.cat((self.updvector_all, self.updvector_one), 0) # [m,d]; for aggregation
            start = end

            del self.align
            del self.attention
            del self.updvector_one

        del self.align1

        # TODO: update the user vector
        if type_name =='aggregation':
            # [mlen(key_list),1]*[ [mlen(key_list),md]-->[m,md]
            for i in range(len(li_aggquery)):
                self.vector_final[int(li_aggquery[i])]  =self.W1*(vector[int(li_aggquery[i])])+(1-self.W1)*(self.updvector_all[i]) #***shape
        else:
            start = 0
            end = 0
            for i in range(len(L_list)):
                end = end + L_list[i]
                for j in range(start,end):
                    self.vector_final[int(L_aggkey[j])] = self.W1 * (vector[int(L_aggkey[j])]) + ( 1 - self.W1) * (self.L_attention[j]*query_vector[i])
                start=end # ***shape


        del self.L_attention
        del self.updvector_all

        return self.vector_final

    def depth_InfluenceStrength(self, query_vector,L_Key,L_list,li_aggquery0, li_aggquery0sum,L_aggkey,vector,attentionIn,layer,updname,type_name):

        # Attention;query,key1,key2,...,keyn,value1,value2,...,valuen;key=value
        # query-q: pre of changed user;key-k: pre of users who trust the changed user;value=key-v
        # hidden_dim=num_items
        # General--align(q, k) = q*W_a*k=[1,hidden_dim]*[hidden_dim,hidden_dim]*[hidden_dim,1]=[1]
        # General_all--align(q, K) = q*W_a*k=[1,hidden_dim]*[hidden_dim,hidden_dim]*[hidden_dim,len(key_list)]=[1,len(key_list)]
        # ×align(q, K) = v^T * tanh(W*[q:k]=[1,hidden_dim]*tanh([hidden_dim,embed_dim]*[embed_dim,rq_num]+[hidden_dim,embed_dim]*[             embed_dim,rq_num])
        # ×align(q, K) = v^T * tanh(W*q+U*k)=[1,hidden_dim]*tanh([hidden_dim,embed_dim]*[embed_dim,rq_num]+[hidden_dim,embed_dim]*[embed_dim,rq_num])
        # attention = softmax(align)=[1,num_items]*[len(key_list),num_items]*[num_items,len(key_list)]=[1,len(key_list)]
        # new_pre=attention*v=[1,len(key_list)]*[len(key_list),item_dim]*

        # General

        # print(layer,attentionIn.size(),len(L_list))

        if updname=='embedding' and type_name =='aggregation':
            self.W=self.params['W_AggUserDep']
            self.W1=self.params['W_uad']
            d = embedding_dimension
        elif updname=='preference' and type_name =='aggregation':
            self.W = self.params['W_AggTypeDep']
            self.W1 = self.params['W_pad']
            d = num_types
        elif updname=='embedding' and type_name =='diffusion':
            self.W=self.params['W_DiffUserDep']
            self.W1=self.params['W_udd']
            d = embedding_dimension
        elif updname=='preference' and type_name =='diffusion':
            self.W= self.params['W_DiffTypeDep']
            self.W1 = self.params['W_pdd']
            d = num_types

        self.vector_final = vector.clone()
        self.align1 = torch.mm(query_vector, self.W)  # [m,d]*[d,d]=[m,d]
        self.attention_final=torch.zeros(L_Key.shape[0], 1)
        m = nn.Softmax(dim=0)

        # TODO: generate the attention
        start = 0
        end = 0
        for i in range(len(L_list)):
            end = end + L_list[i]
            self.align = torch.mm(self.align1[i].reshape(1,d), L_Key[start:end, ].t())
            self.attention = m(self.align.reshape(L_list[i], 1))
            self.updvector_one = (self.attention * L_Key[start:end, ])  # [len(key_list),d]

            if start == 0:
                self.L_attention = self.attention
                self.updvector_all = self.updvector_one
            else:
                self.L_attention = torch.cat((self.L_attention, self.attention), 0) #[mlen(key_list),1]
                self.updvector_all = torch.cat((self.updvector_all, self.updvector_one), 0)  #[mlen(key_list),d]

            if layer != 1:
                self.attention_final[start:end, ] = attentionIn[i] * self.attention

            start = end

            del self.align
            del self.attention
            del self.updvector_one

        if layer==1:
            self.attention_final = self.L_attention

        # TODO: generate the li_aggquery0sumNext
        li_aggquery0sumNext=[]
        self.updvector_all = (self.attention_final.reshape(L_Key.shape[0], 1) * L_Key)  # [mlen(key_list),1]*[ [mlen(key_list),d]-->[mlen(key_list),d]

        # TODO: aggregation
        if type_name =='aggregation':

            if layer==1:
                # update the vector of  initial user by aggregating from friends
                startj = 0
                endj=0
                for i in range(len(li_aggquery0sum)):
                    endj = endj + li_aggquery0sum[i]
                    self.vector_final[li_aggquery0[i]] = self.W1 * (vector[li_aggquery0[i]]) + (1 - self.W1) * ((self.updvector_all[startj:endj, ]).sum(0))
                    li_aggquery0sumNext.append(endj - startj)
                    startj = endj

            else:
                # update the vector of  initial user by aggregating from  friends
                startj=0
                endj = 0
                startk = 0
                endk = 0
                for i in range(len(li_aggquery0sum)):
                    endj = endj + li_aggquery0sum[i]
                    for j in range(startj,endj):
                        endk=endk+L_list[j]
                    self.vector_final[li_aggquery0[i]] = self.W1 * (vector[li_aggquery0[i]]) + (1 - self.W1) * ((self.updvector_all[startk:endk, ]).sum(0))
                    li_aggquery0sumNext.append(endk-startk)
                    startk = endk
                    startj = endj

        # TODO: diffusion
        else:

            if layer==1:
                # diffusion to the friends
                startj=0
                endj = 0
                for i in range(len(li_aggquery0sum)):
                    endj = endj + li_aggquery0sum[i]
                    for j in range(startj,endj):
                        self.vector_final[L_aggkey[j]] = self.W1 * (vector[L_aggkey[j]]) + (1 - self.W1) * (self.attention_final[j]*vector[li_aggquery0[i]])
                    startj = endj

            else:
                # diffusion to the friends via middle friends
                startj=0
                endj = 0
                startk = 0
                endk = 0
                for i in range(len(li_aggquery0sum)):
                    endj = endj + li_aggquery0sum[i]
                    for j in range(startj,endj):  # a 1 user
                        endk=endk+L_list[j]
                        for k in range(startk,endk):  # a 2 user
                            self.vector_final[L_aggkey[k]] = self.W1 * (vector[L_aggkey[k]]) + (1 - self.W1) * (self.attention_final[k]* vector[li_aggquery0[i]])
                        startk=endk
                    startj = endj

        del self.align1
        del self.L_attention
        del self.updvector_all

        return self.vector_final, self.attention_final,li_aggquery0sumNext


class UserItemGraph(nn.Module):

    # aggregation1(one-level): user embedding from item;item embedding from user
    # aggregation2(two-level): user embedding from user-item-user;item embedding from item-user-item and item-type-item
    # aggregation3(three-level): user embedding from user-item-type-item-user

    def __init__(self):
        super(UserItemGraph, self).__init__()
        self.params = nn.ParameterDict({'W_ui': nn.Parameter(torch.rand(embedding_dimension, embedding_dimension)),'W_iu': nn.Parameter(torch.rand(embedding_dimension, embedding_dimension)), 'W_uiu': nn.Parameter(torch.rand(embedding_dimension, embedding_dimension)),'W_iui': nn.Parameter(torch.rand(embedding_dimension, embedding_dimension)),'W_iti': nn.Parameter(torch.rand(embedding_dimension, embedding_dimension)),'W_uitiu': nn.Parameter(torch.rand(embedding_dimension, embedding_dimension)),'W_uig_ui': nn.Parameter(torch.rand(1,1)),'W_uig_uiu': nn.Parameter(torch.rand(1,1)),'W_uig_iu': nn.Parameter(torch.rand(1,1)),'W_uig_iui': nn.Parameter(torch.rand(1,1)),'W_uio': nn.Parameter(torch.rand(1,1)),'W_iuo': nn.Parameter(torch.rand(1,1)),'W_uiuo': nn.Parameter(torch.rand(1,1)),'W_iuio': nn.Parameter(torch.rand(1,1)),'W_itio': nn.Parameter(torch.rand(1,1)),'W_uitiuo': nn.Parameter(torch.rand(1,1))})

    def forward(self,userEmbedding,itemEmbedding,dic_ui, dic_iu, dic_uiu, dic_iui,dic_iti, dic_uitiu):
        # print(self.params['W_uitiuo'][0])

        self.userEmbedding,self.itemEmbedding=userEmbedding.clone(),itemEmbedding.clone()
        self.userEmbedding_ui,self.userEmbedding_uiu,self.userEmbedding_uitiu= userEmbedding.clone(),userEmbedding.clone(),userEmbedding.clone()
        self.itemEmbedding_iu,self.itemEmbedding_iui,self.itemEmbedding_iti= itemEmbedding.clone(), itemEmbedding.clone(),itemEmbedding.clone()
        self.dic_ui, self.dic_iu, self.dic_uiu, self.dic_iui,self.dic_iti, self.dic_uitiu=dic_ui,dic_iu,dic_uiu,dic_iui,dic_iti,dic_uitiu

        # 1user embedding-ui
        self.userEmbedding_ui = self.UIG_aggInfluenceStrength(self.dic_ui, self.userEmbedding,
                                                                  self.itemEmbedding, d=embedding_dimension, wName='ui')

        # 2user embedding-uiu
        self.userEmbedding_uiu = self.UIG_aggInfluenceStrength(self.dic_uiu, self.userEmbedding,
                                                               self.userEmbedding, d=embedding_dimension,
                                                               wName='uiu')

        # 3user embedding-uitiu
        self.userEmbedding_uitiu = self.UIG_aggInfluenceStrength(self.dic_uitiu, self.userEmbedding,
                                                                 self.userEmbedding, d=embedding_dimension,
                                                                 wName='uitiu')

        self.userEmbedding_uig = self.userEmbedding_ui * self.params['W_uig_ui'] + self.userEmbedding_uiu * self.params[
            'W_uig_uiu'] + self.userEmbedding_uitiu * (1 - self.params['W_uig_ui'] - self.params['W_uig_uiu'])

        del self.userEmbedding_ui
        del self.userEmbedding_uiu
        del self.userEmbedding_uitiu

        del self.dic_ui
        del self.dic_uiu
        del self.dic_uitiu

        # 1item embedding-iu
        self.itemEmbedding_iu = self.UIG_aggInfluenceStrength(self.dic_iu, self.itemEmbedding,
                                                              self.userEmbedding, d=embedding_dimension, wName='iu')

        # 2item embedding-iui
        self.itemEmbedding_iui = self.UIG_aggInfluenceStrength(self.dic_iui, self.itemEmbedding, self.itemEmbedding,
                                                               d=embedding_dimension, wName='iui')

        # 3item embedding-iti
        self.itemEmbedding_iti = self.UIG_aggInfluenceStrength(self.dic_iti, self.itemEmbedding,
                                                               self.itemEmbedding, d=embedding_dimension,
                                                               wName='iti')

        self.itemEmbedding_uig = self.itemEmbedding_iu * self.params['W_uig_iu'] + self.itemEmbedding_iui * self.params[
            'W_uig_iui'] + self.itemEmbedding_iti * (1 - self.params['W_uig_iu'] - self.params['W_uig_iui'])

        del self.itemEmbedding_iu
        del self.itemEmbedding_iui
        del self.itemEmbedding_iti

        del self.dic_iu
        del self.dic_iui
        del self.dic_iti

        return self.userEmbedding_uig,self.itemEmbedding_uig


    def UIG_aggInfluenceStrength(self,dic_key,vector1,vector2,d,wName):

        # Attention;query,key1,key2,...,keyn,value1,value2,...,valuen;key=value
        # query-q: pre of changed user;key-k: pre of users who trust the changed user;value=key-v
        # hidden_dim=num_items
        # General--align(q, k) = q*W_a*k=[1,hidden_dim]*[hidden_dim,hidden_dim]*[hidden_dim,1]=[1]
        # General_all--align(q, K) = q*W_a*k=[1,hidden_dim]*[hidden_dim,hidden_dim]*[hidden_dim,len(key_list)]=[1,len(key_list)]
        # ×align(q, K) = v^T * tanh(W*[q:k]=[1,hidden_dim]*tanh([hidden_dim,embed_dim]*[embed_dim,rq_num]+[hidden_dim,embed_dim]*[embed_dim,rq_num])
        # ×align(q, K) = v^T * tanh(W*q+U*k)=[1,hidden_dim]*tanh([hidden_dim,embed_dim]*[embed_dim,rq_num]+[hidden_dim,embed_dim]*[embed_dim,rq_num])
        # attention = softmax(align)=[1,num_items]*[len(key_list),num_items]*[num_items,len(key_list)]=[1,len(key_list)]
        # new_pre=attention*v=[1,len(key_list)]*[len(key_list),item_dim]*

        # General
        self.vector1_final = vector1.clone()

        if wName == 'ui':
            self.W = self.params['W_ui']
            self.Wo = self.params['W_uio']
        elif wName == 'iu':
            self.W = self.params['W_iu']
            self.Wo = self.params['W_iuo']
        elif wName == 'uiu':
            self.W = self.params['W_uiu']
            self.Wo = self.params['W_uiuo']
        elif wName == 'iui':
            self.W = self.params['W_iui']
            self.Wo = self.params['W_iuio']
        elif wName == 'iti':
            self.W = self.params['W_iti']
            self.Wo = self.params['W_itio']
        else:
            self.W = self.params['W_uitiu']
            self.Wo = self.params['W_uitiuo']

        for u in dic_key.keys():
            self.query_vector = vector1[int(u)]  # [1,d]
            self.li_key = [int(i) for i in dic_key[u]]  # int
            if len(self.li_key)>30:
                self.li_key=random.sample(self.li_key,30)
            self.indices = torch.tensor(self.li_key)  # [1,len(key_list)]
            self.Key = torch.index_select(vector2, 0, self.indices)  # 0 选择某几行；[len(key_list),d]
            self.Key = self.Key.t() # 转置;[d,len(key_list)]
            del self.indices

            self.align1=torch.mm(self.query_vector.reshape(1,d),self.W)
            self.align = torch.mm(self.align1, self.Key)  # [1,len(key_list)]
            m = nn.Softmax(dim=1)
            self.attention = m(self.align) # [1,len(key_list)]
            self.updateVector=self.attention.reshape(len(self.li_key), 1) * self.Key.t()
            self.vector1_final[int(u)] = self.Wo*(vector1[int(u)]) +(1- self.Wo)*(self.updateVector.sum(0)) #***shape

            del self.query_vector
            del self.align1
            del self.align
            del self.attention
            del self.Key
            del self.li_key
            del self.updateVector

        return self.vector1_final

class RatePrediction(nn.Module):

    def __init__(self):
        super(RatePrediction, self).__init__()
        self.params = nn.ParameterDict({'W_embed': nn.Parameter(torch.rand(1, 1))})

    def forward(self, userEmbedding, itemEmbedding, userTypePre,arr_itemType,one_mask):

        self.rate = torch.mm(userEmbedding, itemEmbedding.t())*self.params['W_embed'] + torch.mm(userTypePre, arr_itemType.t())*(1-self.params['W_embed'])
        self.final_rate= self.rate.mul(one_mask)

        del self.rate

        return self.final_rate

class network_main(nn.Module):
    def __init__(self):
        super(network_main, self).__init__()

        # 模型中加入一层DisMult层
        self.model1 = UserUserGraph()
        self.model2 = UserItemGraph()
        self.model3 = RatePrediction()

        self.params = nn.ParameterDict({'W_uug': nn.Parameter(torch.rand(1,1))})


    def forward(self,userEmbedding,itemEmbedding,userTypePre,dic_ui, dic_iu, dic_uiu, dic_iui, dic_iti, dic_uitiu,arr_itemType,one_mask):
        # print('before UserUserGraph_pre:',(torch.nonzero(userTypePre<0.001)).size() , id(userTypePre), userTypePre.is_leaf, userTypePre._version,userTypePre.requires_grad)

        # print('UserUserGraph')
        userEmbedding_uug,userTypePre_uug = self.model1(userEmbedding,userTypePre )
        # print('UserUserGraph',time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))

        # print('UserItemGraph')
        userEmbedding_uig, itemEmbedding_uig = self.model2(userEmbedding, itemEmbedding, dic_ui, dic_iu, dic_uiu, dic_iui,
         dic_iti, dic_uitiu)

        final_userEmbedding=userEmbedding_uug*self.params['W_uug']+userEmbedding_uig*(1-self.params['W_uug'])
        # print('UserItemGraph',time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))

        del userEmbedding_uug
        del userEmbedding_uig

        # print('RatePrediction')
        rate = self.model3(final_userEmbedding, itemEmbedding_uig, userTypePre_uug, arr_itemType,one_mask)
        # print('RatePrediction',time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))

        del final_userEmbedding
        del itemEmbedding_uig

        return rate,userTypePre_uug

class newLoss(nn.Module):


    def __init__(self):
        super(newLoss, self).__init__()

    def forward(self, y_pred, y_true, mask):

        self.sum1 = torch.sum((y_pred * mask - y_true * mask) ** 2)
        self.count1 = torch.sum(mask)
        self.loss=self.sum1 / self.count1
        return self.loss


class evaluate_model():
    def __init__(self):
        pass

    def my_loss(self, y_pred, y_true, mask):
        self.sum1 = torch.sum((y_pred * mask - y_true * mask) ** 2)
        self.count1 = torch.sum(mask)
        return self.sum1 / self.count1

        # return self.sum1


    def RMSE(self, y_pred, y_true, mask):
        self.sum1 = torch.sum((y_pred * mask - y_true * mask) ** 2)
        self.count1 = torch.sum(mask)
        return torch.sqrt(self.sum1 / self.count1)


    def MAE(self, y_pred, y_true, mask):
        self.sum1 = torch.sum(torch.abs(y_pred * mask - y_true * mask))
        self.count1 = torch.sum(mask)
        return self.sum1 / self.count1


if __name__ == "__main__":
    print("start time:", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
    warnings.filterwarnings('ignore')

    # sys.stdout = Logger('a.log', sys.stdout)
    # sys.stderr = Logger('a.log_file', sys.stderr)  # redirect std err, if necessary

    # '''
    # hyperparameters
    iterate = 50  # hyperparameter1
    level = 2
    e = 0.3
    embedding_dimension = 64
    win_size =3
    walk_len = 5
    num_walk = 10
    print('iterate:',iterate,', level:', level,', e:', e)
    print('embedding_dimension:',embedding_dimension)
    print('win_size:',win_size)
    print('walk_len:',walk_len)
    print('num_walk:',num_walk)

    '''
    #TODO: for CiaoDVD5
    path = '../Data/CiaoDVD/Final_data/DP_'+str(e)+'/'
    num_users, num_items,num_types,num_timestamps=88,5015,17,14
    num_train,num_valid,num_test = 7,3,4
    '''

    # '''
    # TODO: for Lastfm5
    path = '../Data/Lastfm/Final_data/DP_'+str(e)+'/'
    num_users, num_items, num_types, num_timestamps = 223, 7708, 2665, 17 # 4个时间步合成一个->17
    num_train, num_valid, num_test = 9,3,5 # change
    # '''


    # max_level=7
    # num_choose_max=4

    user_embedding = io.loadmat(path + 'tune/all_time_merge'+str(embedding_dimension)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/all_time_merge_user.mat')
    item_embedding = io.loadmat(path + 'tune/all_time_merge'+str(embedding_dimension)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/all_time_merge_item.mat')


    tag=1 # 训练和验证tag=0:time_stamp-num_train num_valid；训练验证和测试tag=1:time_stamp-num_train+num_valid num_test
    if tag==0:
        num_timestamp1=num_train-1
        num_timestamp2=num_train+num_valid-1
        train_data=io.loadmat(path + 'array_trainvalidtest/train.mat')
        train_rateAll = torch.from_numpy(train_data['train_rate'].astype(np.float32))
        test_data = io.loadmat(path + 'array_trainvalidtest/valid.mat')
        test_rateAll = torch.from_numpy(test_data['valid_rate'].astype(np.float32))

    else:
        num_timestamp1=num_train+num_valid-1
        num_timestamp2=num_train+num_valid+num_test-1
        train_data = io.loadmat(path + 'array_trainvalidtest/train_valid.mat')
        train_rateAll = torch.from_numpy(train_data['train_valid_rate'].astype(np.float32))
        test_data = io.loadmat(path + 'array_trainvalidtest/test.mat')
        test_rateAll = torch.from_numpy(test_data['test_rate'].astype(np.float32))
        test_mask = torch.from_numpy(test_data['test_mask'].astype(np.float32))


    # data_preparation
    gd= data_preparation()  # get class
    em=evaluate_model()
    # dic_trust_users,dic_trusted_users=gd.get_trust_data(trust_data=path+'DP_trust.txt') # str,str for Ciao6
    dic_trust_users, dic_trusted_users = gd.get_trust_data(trust_data=path + 'DP_user_friends.txt')  # str,str for Lastfm6
    dic_iti=gd.get_agg123_allData()  # dic[str]=set(str)
    dic_allTime=gd.get_agg123_timeData()


    # input:one_user_embedding,one_item_embedding,one_train_mask
    # GD_true:one_train_rate
    # model parameters: user_type_pre
    # hyperparmeters: iterate,level

    # train

    model = network_main()
    optimizer = optim.Adam(model.parameters(), lr=0.03,weight_decay=0.01) #lr=1e-2
    newloss = newLoss()

    print('training................................................................')

    # userTypePre = Variable(torch.rand(num_users, num_types), requires_grad=False)

    train_loss_list = []
    train_RMSE_list = []
    train_MAE_list = []

    # userTypePre =  Variable(torch.rand(num_users, num_types),requires_grad = True)

    # userTypePre.requires_grad = True
    # print('self.userTypePre:', id(userTypePre), (torch.nonzero(userTypePre<0.001)).size(),
    #       userTypePre.is_leaf, userTypePre._version,userTypePre.requires_grad)

    # for name, param  in model.named_parameters():
        # print(name, param)

    loss_old=100000
    for i in range(iterate):
        print('iterate:',i,'='*130)
        # for params in model.parameters():
        #     # print(params.requires_grad, ' -->grad_value:', params.grad, params.is_leaf)
        #     print('872',id(params), params.is_leaf, params._version, params.requires_grad)
        #     # params.retain_grad()
        #     print((torch.sum(params<0.001)))
        #     print(id(params))

        # pred_rate=torch.from_numpy(np.zeros((num_users, num_items)).astype(np.float32))
        pred_rate = Variable(torch.zeros(num_users, num_items), requires_grad=False)
        train_mask = Variable(torch.zeros(num_users, num_items), requires_grad=False)
        train_rate = Variable(torch.zeros(num_users, num_items), requires_grad=False)
        userTypePre = torch.rand(num_users, num_types)

        for j in range(0,num_timestamp1):  # #num_timestamp1;012345->123456;(0,6)
            print('timestamps:', j)

            # userEmbedding = torch.from_numpy(user_embedding[str(j)].astype(np.float32))
            # itemEmbedding = torch.from_numpy(item_embedding[str(j)].astype(np.float32))
            # userEmbedding.requires_grad = True
            # itemEmbedding.requires_grad = True

            userEmbedding = Variable(torch.from_numpy(user_embedding[str(j)].astype(np.float32)),requires_grad = True)
            itemEmbedding = Variable(torch.from_numpy(item_embedding[str(j)].astype(np.float32)),requires_grad = True)

            # print("count:", objgraph.count("userEmbeddingh"))
            # print("count:", sys.getrefcount(itemEmbedding))

            dic_ui, dic_iu, dic_uiu, dic_iui, dic_uitiu, arr_itemType = dic_allTime[str(j)]['dic_ui'],  dic_allTime[str(j)]['dic_iu'], dic_allTime[str(j)]['dic_uiu'],                                  dic_allTime[str(j)]['dic_iui'], dic_allTime[str(j)]['dic_uitiu'],  dic_allTime[str(j)]['arr_itemType']
            one_train_mask = dic_allTime[str(j + 1)]['one_arr_mask']
            arr_itemType = torch.from_numpy(arr_itemType.astype(np.float32))
            one_train_mask = torch.from_numpy(one_train_mask.astype(np.float32))
            one_train_rate=train_rateAll[j+1]

            optimizer.zero_grad()  # 参数梯度清零，因为会累加

            # userTypePreIn=userTypePre.clone()
            userTypePreIn =  Variable(userTypePre,requires_grad = True)
            # print('userTypePreIn',id(userTypePreIn))

            one_pred_rate,userTypePreOut=model(userEmbedding,itemEmbedding,userTypePreIn,dic_ui, dic_iu, dic_uiu, dic_iui,
             dic_iti, dic_uitiu,arr_itemType,one_train_mask)
            # print('one_pred_rate:', (torch.nonzero(one_pred_rate<0.001)).size(),type(one_pred_rate),id(one_pred_rate), one_pred_rate.is_leaf, one_pred_rate._version,one_pred_rate.requires_grad)
            # print('userTypePre:', (torch.nonzero(userTypePre < 0.001)).size(), type(userTypePre),
            #       id(userTypePre), userTypePre.is_leaf, userTypePre._version, userTypePre.requires_grad)
            # print(one_pred_rate)

            # print("userTypePreOut",id(userTypePreOut))
            userTypePre=userTypePreOut
            # print('userTypePre',id(userTypePre))

            # print("count:", objgraph.count("userEmbedding"))
            # print("count:", sys.getrefcount(itemEmbedding))

            # print("count3:", objgraph.count("userEmbedding"))

            one_loss =newloss(one_pred_rate,one_train_rate,one_train_mask)

            # one_loss.backward(retain_graph=True)  # loss反向传播
            one_loss.backward()  # loss反向传播
            optimizer.step()
            #
            # print(grads['one_pred_rate'])
            # print((torch.nonzero(one_pred_rate>0.99)).size())
            #

            print(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
            print(one_loss,em.RMSE(one_pred_rate,one_train_rate,one_train_mask),em.MAE(one_pred_rate, one_train_rate, one_train_mask))

            pred_rate = pred_rate + one_pred_rate
            train_mask = train_mask + one_train_mask
            train_rate = train_rate + one_train_rate

            del userEmbedding
            del itemEmbedding

            del dic_ui
            del dic_iu
            del dic_uiu
            del dic_iui
            del dic_uitiu
            del arr_itemType

            del one_pred_rate
            del one_train_mask
            del one_train_rate
            del one_loss

            #
            # g = make_dot(one_pred_rate)
            # g.render('espnet_model', view=False)


        loss = newloss(pred_rate, train_rate, train_mask)
        if loss>loss_old: #or loss<0.05
            print('loss:',loss,'loss old:',loss_old)
            break
        loss_old=loss
        print(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
        print('train:',loss, em.RMSE(pred_rate, train_rate, train_mask), em.MAE(pred_rate, train_rate, train_mask))

        del pred_rate
        del train_rate
        del train_mask

    # for name, param in model.named_parameters():
    #     print(name, param)
    #     params.retain_grad()
    #         print(params.requires_grad, ' -->grad_value:', params.grad, params.is_leaf)
    #     print('919',id(params), params.is_leaf, params._version, params.requires_grad)
    #     print(params.requires_grad, ' -->grad_value:', params.grad, params.is_leaf)

        # print((torch.nonzero(params < 0.001)).size())
        # print(id(params))

    # torch.save(model, path +'model/'+str(iterate)+'.pt')

    # model = torch.load(path +'model/'+str(iterate)+'.pt')

    print('testing................................................................')

    test_pred_rate = torch.zeros(num_users, num_items)
    test_rate = torch.zeros(num_users, num_items)
    test_mask = torch.zeros(num_users, num_items)

    for j in range(num_timestamp1,num_timestamp2):  # #num_timestamp1
        print('timestamps:', j)

        userEmbedding = torch.from_numpy(user_embedding[str(j)].astype(np.float32))
        itemEmbedding = torch.from_numpy(item_embedding[str(j)].astype(np.float32))
        userEmbedding.requires_grad = True
        itemEmbedding.requires_grad = True

        dic_ui, dic_iu, dic_uiu, dic_iui, dic_uitiu, arr_itemType = dic_allTime[str(j)]['dic_ui'], dic_allTime[str(j)][
            'dic_iu'], dic_allTime[str(j)]['dic_uiu'], dic_allTime[str(j)]['dic_iui'], dic_allTime[str(j)]['dic_uitiu'], \
                                                                    dic_allTime[str(j)]['arr_itemType']
        one_test_mask = dic_allTime[str(j + 1)]['one_arr_mask']
        arr_itemType = torch.from_numpy(arr_itemType.astype(np.float32))
        one_test_mask = torch.from_numpy(one_test_mask.astype(np.float32))
        one_test_rate = test_rateAll[j + 1]

        one_test_pred_rate, userTypePre = model(userEmbedding, itemEmbedding, userTypePre, dic_ui, dic_iu, dic_uiu, dic_iui,
                                           dic_iti, dic_uitiu, arr_itemType,one_test_mask)


        one_loss = newloss(one_test_pred_rate, one_test_rate,one_test_mask)

        print(one_loss,em.RMSE(one_test_pred_rate, one_test_rate, one_test_mask),em.MAE(one_test_pred_rate, one_test_rate, one_test_mask))

        del userEmbedding
        del itemEmbedding

        del dic_ui
        del dic_iu
        del dic_uiu
        del dic_iui
        del dic_uitiu
        del arr_itemType

        test_pred_rate = test_pred_rate + one_test_pred_rate
        test_rate = test_rate + one_test_rate
        test_mask = test_mask + one_test_mask

        del one_test_pred_rate
        del one_test_rate
        del one_test_mask


    loss = newloss(test_pred_rate, test_rate, test_mask)
    print('test:',loss, em.RMSE(test_pred_rate, test_rate, test_mask), em.MAE(test_pred_rate, test_rate, test_mask))

    print("finish time:", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
