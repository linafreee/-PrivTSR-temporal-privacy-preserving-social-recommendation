# divide datasets; get key words

import numpy as np
import pandas as pd
from collections import defaultdict
import re
import scipy.io as io
import os
import random

# TODO: process the datasets for CiaoDVD
class data_process():
    def __init__(self):  # self: for this class
        self.path = '../Data/CiaoDVD/'

    def count_num(self,fl_name):
        self.file=self.path+fl_name
        self.all_users=set()
        self.all_items = set()
        self.all_types = set()
        self.all_times=set()
        self.all_timestamps = set()
        self.all_ratings = set()
        f = open(self.file, "r")
        lines = f.readlines()
        for line in lines:
            line = line.strip('\n')
            self.all_users.add(int(line.split(',')[0]))  # for users
            self.all_items.add(int(line.split(',')[1]))  # for items
            self.all_types.add(int(line.split(',')[2]))  # for types
            self.all_timestamps.add(int(line.split(',')[4])) # for timestamps
            self.all_ratings.add(float(line.split(',')[3]))
        print('all_users:',len(self.all_users))
        print('all_items:', len(self.all_items))
        print('all_types:', len(self.all_types))
        print('all_timestamps:', len(self.all_timestamps))
        print(self.all_ratings)
        print(self.all_timestamps)
        
        
    def pre_data_for_trust(self):
            # 删除trust中重复的数据

            self.file = self.path + 'Row_data/trusts.txt'

            self.pre_list=[]  #
            with open(self.path + 'Final_data/Mid_data/trusts.txt', 'a+') as self.f_apmr:
                f = open(self.file, "r")
                lines = f.readlines()
                for line in lines:
                    user1, user2, trust = line.strip().split(',')
                    if (user1, user2) not in self.pre_list:
                        self.f_apmr.write(str(user1)+','+str(user2)+','+str(trust))
                        self.f_apmr.write('\n')
                        self.pre_list.append((user1, user2))


    def pre_data(self):
        # 将数据整理为需要的格式，并删除重复的数据

        self.file = self.path + 'Row_data/movie-ratings.txt'

        self.pre_list=[]  #
        with open(self.path + 'Final_data/Mid_data/pre_movie-ratings.txt', 'a+') as self.f_apmr:
            f = open(self.file, "r")
            lines = f.readlines()
            for line in lines:
                user, item, type,_,rating,time = line.strip().split(',')
                time=int(re.findall(r'(.*)-.*-.*', line.split(',')[5])[0])
                if (user, item) not in self.pre_list:
                    self.f_apmr.write(str(user)+','+str(item)+','+str(type)+','+str(rating)+','+str(time))
                    self.f_apmr.write('\n')
                    self.pre_list.append((user, item))


    def select_user(self):
        # remain: the timestamps corresponding to the users>=3
        self.file = self.path + 'Final_data/Mid_data/pre_movie-ratings.txt'
        self.dic_users_timestamps1 = defaultdict(set)
        self.dic_users_timestamps2 = defaultdict(set)
        self.dic_users_timestamps3 = defaultdict(set)
        f = open(self.file, "r")
        lines = f.readlines()
        self.set_users_all=set()
        for line in lines:
            line = line.strip('\n')
            self.set_users_all.add(int(line.split(',')[0]))
            if 2000<=int(line.split(',')[4])<2007:
                self.dic_users_timestamps1[int(line.split(',')[0])].add(line.split(',')[4])
            if 2007<=int(line.split(',')[4])<2010:
                self.dic_users_timestamps2[int(line.split(',')[0])].add(line.split(',')[4])
            if 2010<=int(line.split(',')[4])<2015:
                self.dic_users_timestamps3[int(line.split(',')[0])].add(line.split(',')[4])
        # print(self.set_users_all)
        # print('all_users_count:',len(self.set_users_all))

        self.li_users_su = set()
        for user in self.set_users_all:
            # if len(self.dic_users_timestamps1[user]) >=2 and len(self.dic_users_timestamps2[user]) >=1 and len(self.dic_users_timestamps3[user]) >=1:
            if len(self.dic_users_timestamps1[user]) >= 1 and len(self.dic_users_timestamps3[user]) >= 1:
                self.li_users_su.add(user)

        self.li_users_su=list(self.li_users_su)
        self.li_users_su.sort()
        # print('self.li_users_su:',self.li_users_su)
        # return list(self.set_users_remain)
        # print('remain_users_count',len(self.set_users_remain))


    def generate_trust_data(self):
        self.trust_data = pd.read_table(self.path + 'Row_data/trusts.txt', sep=',', header=None)
        self.trust_data.columns = [['user0', 'user1', 'relation']]

        self.li_all= []  # 存放需要的用户，之间的用户关系
        k = 0  # 用户关系的数量
        for i in range(len(self.trust_data)):  # 遍历所有用户关系
            # print(all_data.iloc[i])
            # 如果对应的用户0与用户1都是我们需要的用户
            if (self.trust_data.iloc[i]['user0'].values[0] in self.li_users_su) & (self.trust_data.iloc[i]['user1'].values[0] in self.li_users_su):
                # print(all_data.iloc[i])    # 显示打印
                k = k + 1
                # print(k)
                # print(all_data.iloc[i].values.tolist())
                self.li_all.append(self.trust_data.iloc[i].values.tolist())  # 保存 ['用户0', '用户1', '关系']

        self.df_all = pd.DataFrame(self.li_all)  # list 转为 DataFrame

        self.df_all.columns = [['user0', 'user1', 'relation']]  # 1281， 自己提取出来的需要地用户之间的关系
        self.li_users_gtd = self.df_all[['user0']].values.reshape(1, -1)[0].tolist() + \
                            self.df_all[['user1']].values.reshape(1, -1)[0].tolist()  # 2562
        self.li_users_gtd = list(set(self.li_users_gtd))  # 187， 一开始307个用户，挑选完后只剩下187个用户
        self.li_users_gtd = sorted(self.li_users_gtd)  # 用户排序
        x_dic = {}  # 存放用户新的编号
        kk = 0  # 新编号
        for x in self.li_users_gtd:  # 遍历每一个用户的旧编号
            x_dic[x] = kk  # 将新编号存入字典;dic[旧编号int]:新编号int
            kk = kk + 1  # 新编号+1
        self.new_df_all = self.df_all.replace(x_dic)  # 旧编号替换新编号后的关系

        with open(self.path + 'Final_data/trust.txt', 'w') as outfile:
            for i in range(len(self.new_df_all)):
                user0, user1, relation = self.new_df_all.iloc[i].tolist()
                # print(user0, user1, relation)
                outfile.write(str(user0) + ',' + str(user1) + ',' + str(relation) + '\n') #uu[i][j]两个用户共同的business数


        # print('self.li_users_gtd:', self.li_users_gtd)
        # print('x_dic',x_dic)
        # fw = open(self.path + 'Final_data/x_dic.txt', 'w+')
        # fw.write(str(x_dic))  # 把字典转化为str
        # print(len(x_dic))

        return x_dic



    def generat_data(self,x_dic):
        # delete some users; use the remain_users

        self.file = self.path + 'Final_data/Mid_data/pre_movie-ratings.txt'
        # 用户筛选,用户编号重写
        with open(self.path + 'Final_data/Mid_data/gd_movie-ratings0.txt', 'a+') as self.f_apmr:
            f = open(self.file, "r")
            lines = f.readlines()
            for line in lines:
                user, item, type,rating,time = line.strip().split(',')
                if int(user) in self.li_users_gtd:
                    self.f_apmr.write(str(x_dic[int(user)])+','+str(item)+','+str(type)+','+str(rating)+','+str(time))
                    self.f_apmr.write('\n')

        #保留的物品记录
        self.li_item_gd = []
        self.file1 = self.path + 'Final_data/Mid_data/gd_movie-ratings0.txt'
        f1 = open(self.file1, "r")
        lines1 = f1.readlines()
        for line in lines1:
            user, item, type, rating, time = line.strip().split(',')
            self.li_item_gd.append(item)
        self.li_item_gd = list(set(self.li_item_gd))
        self.li_item_gd = sorted(self.li_item_gd)
        kk = 0  # 新编号
        item_dic={}
        for i in self.li_item_gd:  # 遍历每一个用户的旧编号
            item_dic[i] = kk  # 将新编号存入字典;dic[旧编号]str:新编号int
            kk = kk + 1  # 新编号+1
        # fw = open(self.path + 'Final_data/item_dic.txt', 'w')
        # fw.write(str(item_dic))  # 把字典转化为str
        print(len(item_dic))

        #物品重编号
        self.file2 = self.path + 'Final_data/Mid_data/gd_movie-ratings0.txt'
        with open(self.path + 'Final_data/gd_movie-ratings.txt', 'a+') as self.f_apmr2:
            f2 = open(self.file2, "r")
            lines2 = f2.readlines()
            for line in lines2:
                user, item, type, rating, time = line.strip().split(',')
                self.f_apmr2.write(
                        str(user) + ',' + str(item_dic[item]) + ',' + str(type) + ',' + str(float('%.1f' %(int(rating)*0.2))) + ',' + str(time))  #original_data
                # self.f_apmr2.write(
                self.f_apmr2.write('\n')

class DP_data():
    def __init__(self):
        self.path = '../Data/CiaoDVD/'

    def count_score(self,fl_name,str):
        self.file=fl_name
        self.li_score_type=[0 for i in range(num_types)]
        self.li_score_item = [0 for i in range(num_items)]
        self.li_score_trust = [0 for i in range(num_users)]
        # print(self.li_score_type)

        f = open(self.file, "r")
        lines = f.readlines()
        for line in lines:
            # print(line)
            if str=='type':
                _,  _, type, _,_ = line.strip().split(',')
                self.li_score_type[int(type)-1]+=1
            if str=='item':
                _,  item, _,  _,  _ = line.strip().split(',')
                self.li_score_item[int(item)]+=1
            if str == 'trust':
                u1,u2, _ = line.strip().split(',')
                self.li_score_trust[int(u2)] += 1

        if str == 'type':
            self.li_score= self.li_score_type
        if str == 'item':
            self.li_score = self.li_score_item
        if str == 'trust':
            self.li_score = self.li_score_trust

        # print('li_score:', self.li_score)
        return self.li_score

    def expMechanism(self,scores, e, sensitivity):
        probability0 = []
        probability1 = []
        for score in scores:
            probability0.append(np.exp(0.5 * e * score / sensitivity))
        sum = np.sum(probability0)
        # 归一化处理
        for i in range(len(probability0)):
            probability1.append(probability0[i] / sum)
        # print("when epslion={},probability1:".format(e))
        # print(probability1)

        random.seed()
        r = random.randint(0, 99) / 100
        # print(r)
        sum_exp = 0
        for j in range(len(probability1)):
            sum_exp = sum_exp + probability1[j]
            if (sum_exp > r):
                rand = j
                # print(j)
                break
        rand=j
        return rand


    def generate_DP_data(self):
        self.li_rec = list(range(0, num_records))
        self.li_item_s = random.sample(self.li_rec, int(0.3 * num_records))
        self.li_type_s = random.sample(self.li_rec, int(0.3 * num_records))
        self.li_trust_s = random.sample(self.li_rec, int(0.3 * num_records))

        sensitivity_item=1
        sensitivity_type = 1
        sensitivity_trust = 1

        scores_item=self.count_score(self.path + 'Final_data/gd_movie-ratings.txt','item')
        scores_type = self.count_score(self.path + 'Final_data/gd_movie-ratings.txt', 'type')
        scores_trust = self.count_score(self.path + 'Final_data/trust.txt', 'trust')

        print(self.path)
        with open(self.path + 'Final_data/DP_'+str(e)+'/DP_gd_movie-ratings.txt', 'a+') as self.f_rating:
            self.file = self.path+ 'Final_data/gd_movie-ratings.txt'
            self.li_score = []
            f = open(self.file, "r")
            lines = f.readlines()
            i=0
            for line in lines:
                user,self.item, self.type, rating,time = line.strip().split(',')
                self.rating =float(rating)+np.random.laplace(1 / e)
                if i in self.li_item_s:
                    self.item=self.expMechanism(scores_item, e, sensitivity_item)
                if i in self.li_type_s:
                    self.type=self.expMechanism(scores_type, e, sensitivity_type)
                i+=1
                self.f_rating.write(str(user) + ',' + str(self.item) + ',' + str(self.type) + ',' + str(self.rating) + ',' + str(time))
                self.f_rating.write('\n')

        with open(self.path + 'Final_data/DP_'+str(e)+'/DP_trust.txt', 'a+') as self.f_trust:
            self.file = self.path + 'Final_data/trust.txt'
            self.li_score = []
            f = open(self.file, "r")
            lines = f.readlines()
            i = 0
            for line in lines:
                user1, user2,relation = line.strip().split(',')
                if i in self.li_item_s:
                    self.user2 = self.expMechanism(scores_trust, e, sensitivity_trust)
                i += 1
                self.f_trust.write(str(user1)+ ',' +str(user2)+ ',' +str(relation))
                self.f_trust.write('\n')


# TODO: divide the datasets
class to_array():
    def __init__(self):
        self.path = '../Data/CiaoDVD/'

    def divide_data(self):
        # train-vali;train_vali-test
        self.fl_gd = open(self.path + 'Final_data/DP_'+str(e)+'/DP_gd_movie-ratings.txt', "r")  #DP_'+e+'/DP_
        self.lines_gd = self.fl_gd.readlines()
        for line in self.lines_gd:
            line = line.strip('\n')
            if 2000 <= int(line.split(',')[4]) < 2007:
                with open(self.path + 'Final_data/DP_'+str(e)+'/DP_gd_train.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
                with open(self.path + 'Final_data/DP_'+str(e)+'/DP_gd_train_valid.txt', 'a+') as self.fl_tv:
                    self.fl_tv.write(line)
                    self.fl_tv.write('\n')
            if 2007 <= int(line.split(',')[4]) < 2010:
                with open(self.path + 'Final_data/DP_'+str(e)+'/DP_gd_valid.txt', 'a+') as self.fl_va:
                    self.fl_va.write(line)
                    self.fl_va.write('\n')
                with open(self.path + 'Final_data/DP_'+str(e)+'/DP_gd_train_valid.txt', 'a+') as self.fl_tv:
                    self.fl_tv.write(line)
                    self.fl_tv.write('\n')
            if 2010 <= int(line.split(',')[4]) < 2015:
                with open(self.path + 'Final_data/DP_'+str(e)+'/DP_gd_test.txt', 'a+') as self.fl_te:
                    self.fl_te.write(line)
                    self.fl_te.write('\n')

    def divide_data0(self):
        # train-vali;train_vali-test
        self.fl_gd = open(self.path + 'Final_data/gd_movie-ratings.txt', "r")  #DP_'+e+'/DP_
        self.lines_gd = self.fl_gd.readlines()
        for line in self.lines_gd:
            line = line.strip('\n')
            if 2000 <= int(line.split(',')[4]) < 2007:
                with open(self.path + 'Final_data/gd_train.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
                with open(self.path + 'Final_data/gd_train_valid.txt', 'a+') as self.fl_tv:
                    self.fl_tv.write(line)
                    self.fl_tv.write('\n')
            if 2007 <= int(line.split(',')[4]) < 2010:
                with open(self.path + 'Final_data/gd_valid.txt', 'a+') as self.fl_va:
                    self.fl_va.write(line)
                    self.fl_va.write('\n')
                with open(self.path + 'Final_data/gd_train_valid.txt', 'a+') as self.fl_tv:
                    self.fl_tv.write(line)
                    self.fl_tv.write('\n')
            if 2010 <= int(line.split(',')[4]) < 2015:
                with open(self.path + 'Final_data/gd_test.txt', 'a+') as self.fl_te:
                    self.fl_te.write(line)
                    self.fl_te.write('\n')


    def divide_data_timestamp(self):
        # train-vali;train_vali-test
        self.fl_gd = open(self.path + 'Final_data/'+ 'DP_'+str(e)+'/DP_gd_movie-ratings.txt', "r")
        self.lines_gd = self.fl_gd.readlines()
        for line in self.lines_gd:
            line = line.strip('\n')
            if int(line.split(',')[4])  == 2000:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+'2000.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4])  == 2001:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2001.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4]) == 2002:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2002.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4])  == 2003:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2003.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4]) == 2004:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2004.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4])  == 2005:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2005.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4])  == 2006:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2006.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4]) == 2007:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2007.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4])  == 2008:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2008.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4])  == 2009:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2009.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4])  == 2010:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2010.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4]) == 2011:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2011.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4]) == 2012:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2012.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
            if int(line.split(',')[4]) == 2013:
                with open(self.path + 'Final_data/DP_'+str(e)+'/timestamp_movie_ratings/'+ '2013.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')


    def txt_to_array(self,s0,t_num,u_num,i_num):
        self.list=[]

        self.arr_rate = np.zeros((t_num,u_num,i_num))  # for CiaoDVD;timestamps:users:items=rate
        self.arr_mask = np.zeros((t_num,u_num,i_num))  # for CiaoDVD;timestamps:users:items=types
        self.fl_s0 = open(self.path + 'Final_data/DP_'+str(e)+'/DP_gd_'+s0+'.txt', "r")
        self.lines_s0 = self.fl_s0.readlines()

        for line in self.lines_s0:
            line = line.strip('\n')
            self.timestamp=int(line.split(',')[4])-2000
            self.arr_rate[self.timestamp][int(line.split(',')[0])][int(line.split(',')[1])]=float(line.split(',')[3])
            self.arr_mask[self.timestamp][int(line.split(',')[0])][int(line.split(',')[1])] = 1
            if (int(line.split(',')[0]),int(line.split(',')[1])) in self.list:
                print('wrong'*30)
                print((int(line.split(',')[0]),int(line.split(',')[1])))
            else:
                self.list.append((int(line.split(',')[0]),int(line.split(',')[1])))
        # print(self.arr_rate[1],self.arr_mask[1])
        io.savemat(self.path + 'Final_data/DP_'+str(e)+'/array_trainvalidtest/'+s0+'.mat', {s0+'_rate': self.arr_rate, s0 + '_mask': self.arr_mask})



class merge_embedding():
    def __init__(self):
        self.path = '../Data/CiaoDVD/Final_data'
        self.timestamp_list=['2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013']


    def merge_user(self):
        self.dic_trust = {}
        self.file_trust = open(self.path + '/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/trust_embedding.txt', "r")
        self.lines_trust = self.file_trust.readlines()
        for line in self.lines_trust[1:]:
            user = line.strip('\n').split(sep=' ')[0]  # str
            self.embedding_str = line.strip('\n').split(sep=' ')[1:]
            self.embedding = [float(x) for x in self.embedding_str]  # list[float]
            self.dic_trust[user]=self.embedding
        # print(self.dic_trust.keys())

        all_time_dict = {}
        for i in self.timestamp_list:
            print(i,'*'*100)
            self.dic_uiu={}
            self.dic_uitiu={}

            if os.path.exists(self.path + '/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/'+str(i)+'_uiu_embedding.txt')==True:
                self.file_uiu = open(self.path + '/DP_'+str(e)+ '/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/' + str(i) + '_uiu_embedding.txt', "r")
                self.lines_uiu = self.file_uiu.readlines()
                for line in self.lines_uiu[1:]:
                    user = line.strip('\n').split(sep=' ')[0]  # str
                    self.embedding_str = line.strip('\n').split(sep=' ')[1:]
                    self.embedding = [float(x) for x in self.embedding_str]  # list[float]
                    self.dic_uiu[user] = self.embedding

            self.file_uitiu = open(self.path + '/DP_'+str(e)+ '/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/' + str(i) + '_uitiu_embedding.txt', "r")
            self.lines_uitiu = self.file_uitiu.readlines()
            for line in self.lines_uitiu[1:]:
                user = line.strip('\n').split(sep=' ')[0]  # str
                self.embedding_str = line.strip('\n').split(sep=' ')[1:]
                self.embedding = [float(x) for x in self.embedding_str]  # list[float]
                self.dic_uitiu[user] = self.embedding

            # print(list(self.dic_uiu.keys()))
            # print(list(self.dic_uitiu.keys()))

            all_user = set(list(self.dic_uiu.keys()) + list(self.dic_uitiu.keys()) + list(self.dic_trust.keys()))
            # assert (len(all_user) == len(self.dic_trust.keys()))

            # print(all_user)

            all_user_dict = {}
            for k in list(self.dic_trust.keys()):
                if (k in list(self.dic_uiu.keys())) and (k not in list(self.dic_uitiu.keys())):
                    all_user_dict[k] = np.average([self.dic_uiu[k], self.dic_trust[k]], axis = 0)
                if (k not in list(self.dic_uiu.keys())) and (k in list(self.dic_uitiu.keys())):
                    all_user_dict[k] = np.average([self.dic_uitiu[k], self.dic_trust[k]], axis=0)
                if (k in list(self.dic_uiu.keys())) and (k in list(self.dic_uitiu.keys())):
                    all_user_dict[k] = np.average([self.dic_uiu[k], self.dic_uitiu[k], self.dic_trust[k]], axis=0)
                if (k not in list(self.dic_uiu.keys())) and (k not in list(self.dic_uitiu.keys())):
                    all_user_dict[k] = self.dic_trust[k]


            all_user_numpy = np.zeros((num_users, dim))
            for u in all_user_dict.keys():
                all_user_numpy[int(u)] = all_user_dict[u]
            # print(all_user_numpy)
            all_time_dict[str(int(i)-2000)] = all_user_numpy
            # np.save(self.path + '/timestamp_merged_embedding/' + i + '_merge', all_user_numpy)
        io.savemat(self.path + '/DP_'+str(e)+'/tune/all_time_merge'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/all_time_merge_user.mat', all_time_dict)  # dic[timestamp]=array

    def merge_item(self):

        self.dic_iti = {}
        self.file_iti = open(self.path + '/DP_'+str(e)+ '/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/iti_embedding.txt', "r")
        self.lines_iti = self.file_iti.readlines()
        for line in self.lines_iti[1:]:
            item = line.strip('\n').split(sep=' ')[0]  # str
            self.embedding_str = line.strip('\n').split(sep=' ')[1:]
            self.embedding = [float(x) for x in self.embedding_str]  # list[float]
            self.dic_iti[item] = self.embedding

        all_time_dict = {}
        for i in self.timestamp_list:
            print(i,'*'*100)
            self.dic_iui={}

            self.file_iui = open(self.path + '/DP_'+str(e)+ '/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/'+str(i)+'_iui_embedding.txt', "r")
            self.lines_iui = self.file_iui.readlines()
            for line in self.lines_iui[1:]:
                item = line.strip('\n').split(sep=' ')[0]  # str
                self.embedding_str = line.strip('\n').split(sep=' ')[1:]
                self.embedding = [float(x) for x in self.embedding_str]  # list[float]
                self.dic_iui[item] = self.embedding

            # print(len(list(self.dic_iui.keys())))
            # print(len(list(self.dic_iti.keys())))

            all_item = set(list(self.dic_iui.keys()) + list(self.dic_iti.keys()))
            # assert (len(all_item) == len(self.dic_iti.keys()))

            all_item_dict = {}
            for k in list(self.dic_iti.keys()):
                if (k in list(self.dic_iui.keys())) and (k not in list(self.dic_iti.keys())):
                    all_item_dict[k] = self.dic_iui[k]
                    print('wrong-----------------------------------------------')
                if (k not in list(self.dic_iui.keys())) and (k in list(self.dic_iti.keys())):
                    all_item_dict[k] = self.dic_iti[k]
                if (k in list(self.dic_iui.keys())) and (k in list(self.dic_iti.keys())):
                    all_item_dict[k] = np.average([self.dic_iui[k], self.dic_iti[k]], axis=0)
            # print(len(all_item_dict['0']))


            all_item_numpy = np.random.rand(num_items, dim)
            # print('len',(len(all_item_dict.keys()), len(all_item_dict['0'])))
            for item in all_item_dict.keys():
                all_item_numpy[int(item)] = all_item_dict[item]
            # print(all_item_numpy)
            all_time_dict[str(int(i)-2000)] = all_item_numpy
            # np.save(self.path + '/timestamp_merged_embedding/' + i + '_merge', all_item_numpy)
        io.savemat(self.path + '/DP_'+str(e)+'/tune/all_time_merge'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/all_time_merge_item.mat', all_time_dict)

    def get_average_merge(self,file_name):
        x = io.loadmat(self.path +'/DP_'+str(e)+'/tune/all_time_merge'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/all_time_merge_'+ file_name+'.mat')

        X=None
        len=14
        for i in range(len):  # 14 for ciao
            if i ==0:
                X=x[str(i)]
                print(x[str(i)].shape)
            else:
                    X+=x[str(i)]
        X=X/len

        print(X.shape)
        print(type(X))
        np.save(self.path+'/DP_'+str(e)+'/tune/all_time_merge'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/mean_'+file_name+'.npy', X)


if __name__ == "__main__":
    num_records=6689
    num_users=88
    num_items=5015
    num_types=17  #1~17

    e=0.9
    dim=16
    win_size = 2
    walk_len = 5
    num_walk = 10
    print(e,dim,win_size, walk_len, num_walk)

    # class
    d_p=data_process()
    d_d = DP_data()
    t_a=to_array()
    me=merge_embedding()


     # function
    # d_p.pre_data()
    # d_p.count_num('Final_data/Mid_data/pre_movie-ratings.txt')  # before data preprocess-'Final_data/pre_movie-ratings.txt' # after data preprocess-'Final_data/gd_movie-ratings.txt'
    d_p.pre_data_for_trust()

    # d_p.select_user()
    # x_dic=d_p.generate_trust_data()
    # d_p.generat_data(x_dic)  # ap_movie-ratings
    # after data preprocess-'Final_data/gd_movie-ratings.txt'

    # d_d.generate_DP_data()

    # t_a.divide_data0() # to txt;train valid trai/n-valid test
    # t_a.divide_data() # to txt;train valid trai/n-valid test
    # t_a.divide_data_timestamp()
    #
    # li_s0=['train','valid','train_valid','test']
    # for s0 in li_s0:
    #     t_a.txt_to_array(s0,14,88,5015)


    # me.merge_user()
    # me.merge_item()

    # me.get_average_merge('user')
    # me.get_average_merge('item')







