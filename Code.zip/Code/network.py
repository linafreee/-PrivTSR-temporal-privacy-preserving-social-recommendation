import torch
import torchvision
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import sys
import math
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
import torch.nn as nn
import torch.nn.functional as F
import os
import networkx as nx
import numpy as np

class Logger(object):
    def __init__(self, filename="Default.log"):
        self.terminal = sys.stdout
        self.log = open(filename, "a")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass

path = os.path.abspath(os.path.dirname(__file__))
type = sys.getfilesystemencoding()
sys.stdout = Logger('b.txt')

print(path)
print(os.path.dirname(__file__))

class network_main():
    def __init__(self,one_train_rate, one_train_mask,one_train_type_pre, one_train_type_pre_last,train_type_item,
                 one_valid_rate, one_valid_mask, one_valid_type_pre,one_valid_type_pre_last, valid_type_item,
                 trust,user_item_pre,user_type_pre,max_level,num_users,num_items,num_choose_max,num_types):
        self.train_rate=torch.from_numpy(one_train_rate)
        self.train_mask=torch.from_numpy(one_train_mask)
        self.train_type_pre = torch.from_numpy(one_train_type_pre)
        self.train_type_pre_last = torch.from_numpy(one_train_type_pre_last)
        self.train_type_item = torch.from_numpy(train_type_item)

        self.valid_rate=torch.from_numpy(one_valid_rate)
        self.valid_mask=torch.from_numpy(one_valid_mask)
        self.valid_type_pre = torch.from_numpy(one_valid_type_pre)
        self.valid_type_pre_last = torch.from_numpy(one_valid_type_pre_last)
        self.valid_type_item = torch.from_numpy(valid_type_item)

        self.trust = torch.from_numpy(trust)

        self.user_type_pre = user_type_pre
        self.user_item_pre = user_item_pre


        self.max_level=max_level
        self.num_users=num_users
        self.num_items=num_items
        self.num_types=num_types


        self.li_changed_user,self.dic_changed_index,self.dic_changed_item_index,self.one_train_type_pre_change,self.one_train_item_pre_change = \
            self.get_changed_index(one_train_type_pre,one_train_type_pre_last,train_type_item,num_choose_max)  # list;train

        self.li_changed_user2, self.dic_changed_index2, self.dic_changed_item_index2, self.one_valid_type_pre_change, self.one_valid_item_pre_change = \
            self.get_changed_index(one_valid_type_pre, one_valid_type_pre_last, valid_type_item, num_choose_max)  # list;valid


    def get_changed_index(self,one_train_type_pre,one_train_type_pre_last,type_item,num_choose_max):
        self.one_train_type_pre_change = one_train_type_pre_last - one_train_type_pre
        self.type_item = type_item

        self.one_train_item_pre_change=np.zeros((self.num_users,self.num_items))
        self.one_train_item_pre_mask= np.ones((self.num_users, self.num_items))

        self.li_changed_user=[]  # set_user
        self.dic_changed_type_index = {}  # user-type
        self.dic_changed_item_index = {}  # user-item
        self.i=0

        for i in range(one_train_type_pre.shape[0]):
            self.li_changed_type_index = []  # type
            self.set_changed_item_index = set()  # item
            if np.abs(self.one_train_type_pre_change[i]).sum()!=0:
                self.li_changed_user.append(i)
                for j in range(one_train_type_pre.shape[1]):
                    if self.one_train_type_pre_change[i][j]!= 0:
                        self.li_changed_type_index.append(j)
                        # for item
                        self.ind = set(np.argpartition(self.type_item[j], -num_choose_max)[-num_choose_max:])  # get item index
                        self.set_changed_item_index=self.set_changed_item_index|self.ind  # set and
                        for k in self.ind:
                            self.one_train_item_pre_change[i][k]+=self.one_train_type_pre_change[i][j]
                            self.one_train_item_pre_mask[i][k] += 1

            self.dic_changed_type_index[i]=self.li_changed_type_index
            self.dic_changed_item_index[i]=list(self.set_changed_item_index)

        self.one_train_item_pre_change=self.one_train_item_pre_change/self.one_train_item_pre_mask

        return self.li_changed_user,self.dic_changed_type_index,self.dic_changed_item_index,\
               torch.from_numpy(self.one_train_type_pre_change),torch.from_numpy(self.one_train_item_pre_change)

    def my_loss(self, y_pred, y_true,mask):
        self.sum1 = torch.sum((y_pred*mask - y_true*mask)**2)
        self.count1 = torch.sum(mask)
        return self.sum1/self.count1

    def RMSE(self, y_pred, y_true,mask):
        self.sum1 = torch.sum((y_pred*mask - y_true*mask)**2)
        self.count1 = torch.sum(mask)
        return torch.sqrt(self.sum1/self.count1)

    def MAE(self, y_pred, y_true,mask):
        self.sum1 = torch.sum(torch.abs(y_pred*mask - y_true*mask))
        self.count1 = torch.sum(mask)
        return self.sum1/self.count1

    def model(self):
        # self.user_item_pre=IncrementalPreferences(self.train_type_pre,self.train_type_item,self.user_item_pre)
        model1 = InfluenceDiffusion(self.trust, self.max_level, self.num_users, self.num_items)
        model2 = RatePrediction(self.num_users)

        # TODO:train

        optimizer = optim.SGD([{'params': model1.parameters()}, {'params': model2.parameters()}], lr=1e-2,weight_decay=0.01)
        loss_list = []  # 保存loss，便于画图
        train_RMSE=[]
        train_MAE=[]
        step = 500  # 迭代次数

        for epoch in range(step):
            optimizer.zero_grad()  # 参数梯度清零，因为会累加
            self.user_type_pre, self.user_item_pre = model1(self.one_train_type_pre_change,self.one_train_item_pre_change,
                                                            self.user_type_pre, self.user_item_pre,self.li_changed_user,
                                                            self.dic_changed_index,self.dic_changed_item_index)
            self.rate = model2(self.user_type_pre, self.user_item_pre,self.train_type_item)
            loss = self.my_loss(self.rate, self.train_rate,self.train_mask)  # 计算输出与target数据的均方差
            loss_list.append(loss)  # 保存loss
            loss.backward()  # loss反向传播
            optimizer.step()

            train_RMSE.append(self.RMSE(self.rate, self.train_rate, self.train_mask))
            train_MAE.append(self.MAE(self.rate, self.train_rate, self.train_mask))

            # if (epoch + 1)%20 == 0:
            #     print('epoch[{}],loss:{:.6f}'.format(epoch+1,loss.data[0]))

        print('loss:',loss_list)
        print('train RMSE:', torch.mean(torch.tensor(train_RMSE)))
        print('train MAE:', torch.mean(torch.tensor(train_MAE)))


        # # TODO:valuate
        # self.user_type_pre2, self.user_item_pre2 = model1(self.one_valid_type_pre_change, self.one_valid_item_pre_change,
        #                                                 self.user_type_pre, self.user_item_pre, self.li_changed_user2,
        #                                                 self.dic_changed_index2, self.dic_changed_item_index2)
        # self.rate2 = model2(self.user_type_pre2, self.user_item_pre2, self.valid_type_item)
        # loss2 = self.my_loss(self.rate2, self.valid_rate,self.valid_mask)  # 计算输出与target数据的均方差
        # print("loss2: ", loss2)
        #
        # print('valid RMSE:',self.RMSE(self.rate2, self.valid_rate,self.valid_mask))
        # print('valid MAE:', self.MAE(self.rate2, self.valid_rate, self.valid_mask))


        return self.user_type_pre,self.user_item_pre


class IncrementalPreferences(nn.Module):

    def __init__(self,train_type_pre,train_type_item,user_item_pre):
        super(IncrementalPreferences, self).__init__()
        self.train_type_pre = train_type_pre
        self.train_type_item = train_type_item
        self.user_item_pre=user_item_pre

    def forward(self):
        self.update = torch.mul(self.train_type_pre,self.train_type_item)
        self.user_item_pre=torch.mean(self.update,self.user_item_pre)
        return self.user_item_pre


class InfluenceDiffusion(nn.Module):

    def __init__(self, trust, max_level,num_users,num_items):
        super(InfluenceDiffusion, self).__init__()

        self.trust=trust



        self.max_level = max_level
        self.num_users = num_users
        self.num_items=num_items

        self.num_trust_all, self.num_trust_max = self.user_influence()

        # self.params = nn.ParameterDict({'v_T': nn.Parameter(torch.randn(4, 4)),
        #                                 'W': nn.Parameter(torch.randn(4, 4)),
        #                                 'U': nn.Parameter(torch.randn(4, 4))})

        # general
        self.params = nn.ParameterDict({'W': nn.Parameter(torch.randn(self.num_items, self.num_items))})

    def forward(self,origin_utp,origin_uip,user_type_pre,user_item_pre,changed_user,dic_changed_type_index,dic_changed_item_index):
        self.user_type_pre = user_type_pre
        self.user_item_pre = user_item_pre
        self.changed_user = changed_user
        self.dic_changed_type_index = dic_changed_type_index
        self.dic_changed_item_index = dic_changed_item_index

        for i in self.changed_user:
            # diffusion user
            self.li_query_user=[]  # list
            self.li_query_user.append(i)
            self.num_trust = int(self.num_trust_all[i])  #  the number of users that trust the user
            self.level=int(self.max_level/self.num_trust_max)*self.num_trust
            self.li_changed_type_index=self.dic_changed_type_index[i]
            self.li_changed_item_index = self.dic_changed_item_index[i]
            self.changed_level_utp=origin_utp
            self.changed_level_uip=origin_uip
            for j in range(self.level):  # diffusion level
                self.last_level_utp=self.user_type_pre
                self.last_level_uip = self.user_item_pre
                self.li_query_user,self.user_type_pre,self.user_item_pre=self.diffusion(self.li_query_user,j,
                        self.li_changed_type_index,self.li_changed_item_index,self.changed_level_utp,self.changed_level_uip) # every diffusion level
                self.changed_level_utp=self.user_type_pre-self.last_level_utp
                self.changed_level_uip = self.user_item_pre - self.last_level_uip

        return self.user_type_pre, self.user_item_pre

    def user_influence(self):
        # A
        self.num_trust=torch.sum(self.trust, 0)  # 1 dim
        self.num_trust_max = int(self.num_trust.max().item())  # int constant
        return self.num_trust,self.num_trust_max

    def num_diffusion_layer(self):
        pass

    def diffusion(self,li_query_user,current_level,li_changed_type_index,li_changed_item_index,
                  changed_level_utp,changed_level_uip):
        self.li_query_user=li_query_user  # list
        self.set_next_query_user=set()  # set
        self.current_level=current_level
        self.li_changed_type_index=li_changed_type_index
        self.li_changed_item_index=li_changed_item_index
        self.changed_level_utp=changed_level_utp
        self.changed_level_uip=changed_level_uip
        for q_user in self.li_query_user:
            self.li_key_user=[]  # list
            for k in range(self.num_users):  # the user trust the diffusion user
                if int(self.trust[q_user, k].item()) == 1:
                    self.li_key_user.append(k)
                    self.set_next_query_user.add(k)
                    # update the preference
            self.type_strength = self.influence_strength(q_user, self.li_key_user, self.user_type_pre)

            self.changed_plus_type= torch.zeros(self.num_users,self.user_type_pre.shape[1])
            self.changed_plus_type[torch.tensor(self.li_key_user),:] =changed_level_utp[q_user]

            self.changed_plus_weight_indices_type=torch.zeros(self.num_users,dtype=torch.uint8)
            self.changed_plus_weight_type=torch.zeros(self.num_users)
            self.changed_plus_weight_indices_type[torch.tensor(self.li_key_user)]=1
            self.changed_plus_weight_type[self.changed_plus_weight_indices_type]=torch.tensor(self.type_strength)

            self.user_type_pre=self.user_type_pre+self.changed_plus_type*self.changed_plus_weight_type.reshape(self.num_users,1)

            self.item_strength = self.influence_strength(q_user, self.li_key_user, self.user_item_pre)

            self.changed_plus_item = torch.zeros(self.num_users, self.num_items)
            self.changed_plus_item[torch.tensor(self.li_key_user), :] = changed_level_uip[q_user]

            self.changed_plus_weight_indices_item = torch.zeros(self.num_users, dtype=torch.uint8)
            self.changed_plus_weight_item = torch.zeros(self.num_users)
            self.changed_plus_weight_indices_item[torch.tensor(self.li_key_user)] = 1
            self.changed_plus_weight_item[self.changed_plus_weight_indices_item] = torch.tensor(self.item_strength)

            self.user_item_pre=self.user_item_pre+self.changed_plus_item*self.changed_plus_weight_item.reshape(self.num_users,1)

            
        return self.list(self.set_next_query_user),self.user_type_pre,self.user_item_pre


    def influence_strength(self,query_user,li_key_users,pre):
        # Attention;query,key1,key2,...,keyn,value1,value2,...,valuen;key=value
        # query-q: pre of changed user;key-k: pre of users who trust the changed user;value=key-v
        #hidden_dim=num_items
        # General--align(q, k) = q*W_a*k=[1,hidden_dim]*[hidden_dim,hidden_dim]*[hidden_dim,1]=[1]
        # General_all--align(q, K) = q*W_a*k=[1,hidden_dim]*[hidden_dim,hidden_dim]*[hidden_dim,len(key_list)]=[1,len(key_list)]
        # ×align(q, K) = v^T * tanh(W*[q:k]=[1,hidden_dim]*tanh([hidden_dim,embed_dim]*[embed_dim,rq_num]+[hidden_dim,embed_dim]*[embed_dim,rq_num])
        # ×align(q, K) = v^T * tanh(W*q+U*k)=[1,hidden_dim]*tanh([hidden_dim,embed_dim]*[embed_dim,rq_num]+[hidden_dim,embed_dim]*[embed_dim,rq_num])
        # attention = softmax(align)=[1,num_items]*[len(key_list),num_items]*[num_items,len(key_list)]=[1,len(key_list)]
        # new_pre=attention*v=[1,len(key_list)]*[len(key_list),item_dim]*
        self.query_user=query_user
        self.key_list=li_key_users

        # General
        self.query=self.user_item_pre[self.query_user] # [1,num_items]
        self.indices=torch.Tensor(self.key_list) # 1*num_items
        self.Key=torch.index_select(pre, 0, self.indices)  # [len(key_list),num_items]
        self.Key=self.key.t()
        self.align =self.query*self.params['W']*self.K  #[1,len(key_list)]

        m = nn.Softmax(dim=0)
        self.attention=m(self.align)
        return self.attention


class RatePrediction(nn.Module):

    def __init__(self,num_users):
        super(RatePrediction, self).__init__()

        self.params_rp = nn.ParameterDict({'w1': nn.Parameter(torch.randn(num_users, 1)),
                                        'w2': nn.Parameter(torch.randn(num_users, 1))})

    def forward(self,user_type_pre, user_item_pre,type_item):
        self.user_type_pre = user_type_pre
        self.user_item_pre = user_item_pre
        self.type_item = type_item
        self.type_to_item=self.user_type_pre.mm(self.type_item)
        self.rate=self.type_to_item*self.params_rp['w1']+self.user_item_pre*self.params_rp['w2']
        return self.rate
