#!/usr/bin/python
import sys
import numpy as np
import random

class metapathGeneration:
    def __init__(self, unum, inum, tnum):
        self.unum = unum  # user;0-100
        self.inum = inum  # item;0-4825
        self.tnum = tnum # type;1-17-->0-16

    def load_ui(self, ui_itfile):
        # txt中user, item, rating变为矩阵user, item，0/1
        ui = np.zeros((self.unum, self.inum))
        with open(ui_itfile, 'r') as infile:
            for line in infile.readlines():
                user, item, _, _,_ = line.strip().split(',')  # for Ciao
                # user, item, _,_= line.strip().split(',') # for Lastfm
                ui[int(user)][int(item)] = 1
        return ui

    def load_it(self, ui_itfile):
        # txt中user, item, rating变为矩阵user, item，0/1
        it = np.zeros((self.inum, self.tnum))
        with open(ui_itfile, 'r') as infile:
            for line in infile.readlines():
                _, item, type, _, _ = line.strip().split(',')  # for Ciao
                # _, item, type,_ = line.strip().split(',') # for Lastfm
                it[int(item)][int(type)-1] = 1  # for Ciao
                # it[int(item)][int(type)] = 1 # for Lastfm
        return it

    def get_UIU(self, ui, targetfile):
        print('UIU...')

        uiu = ui.dot(ui.T)
        print(uiu.shape)
        print('writing to file...')
        total = 0
        with open(targetfile, 'w') as outfile:
            for i in range(uiu.shape[0]):
                for j in range(uiu.shape[1]):
                    if uiu[i][j] != 0 and i != j:
                        outfile.write(str(i) + '\t' + str(j) + '\t' + str(int(uiu[i][j])) + '\n')
                        total += 1
        print('total = ', total)

    def get_UITIU(self, ui, it,  targetfile):
        print('UITIU...')
        uitiu = ui.dot(it).dot(it.T).dot(ui.T)

        print(uitiu.shape)
        print('writing to file...')
        total = 0 
        with open(targetfile, 'w') as outfile:
            for i in range(uitiu.shape[0]):
                for j in range(uitiu.shape[1]):
                    if uitiu[i][j] != 0 and i != j:
                        outfile.write(str(i) + '\t' + str(j) + '\t' + str(int(uitiu[i][j])) + '\n')
                        total += 1
        print('total = ', total)
                                                                                                                                     

    def get_IUI(self, ui, targetfile):
        print('IUI...') #

        iui = ui.T.dot(ui)  #ubu吧
        print(iui.shape)
        print('writing to file...')
        total = 0
        with open(targetfile, 'w') as outfile:
            for i in range(iui.shape[0]):
                for j in range(iui.shape[1]):
                    if iui[i][j] != 0 and i != j:
                        outfile.write(str(i) + '\t' + str(j) + '\t' + str(int(iui[i][j])) + '\n') #uu[i][j]两个用户共同的business数
                        total += 1
        print('total = ', total)
    
    def get_ITI(self, it, targetfile):
        print('ITI...') # 用用户连接物品；物品-用户-物品
        iti = it.dot(it.T)
        print(iti.shape)
        print('writing to file...')
        total = 0
        with open(targetfile, 'w') as outfile:
            for i in range(iti.shape[0]):
                for j in range(iti.shape[1]):
                    if iti[i][j] != 0 and i != j:
                        outfile.write(str(i) + '\t' + str(j) + '\t' + str(int(iti[i][j])) + '\n')
                        total += 1
        print('total = ', total)
    


if __name__ == '__main__':
    e=0.9
    print(e)
    # '''
    #TODO: CiaoDVD
    path = '../Data/CiaoDVD/Final_data/'
    m_g=metapathGeneration(unum=88, inum=5015, tnum=17) #Ciao

    it = m_g.load_it(path + 'DP_'+str(e)+'/DP_gd_movie-ratings.txt')
    m_g.get_ITI(it, path + 'DP_'+str(e)+'/timestamp_metapath/iti.txt')

    nameList=['2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013']
    for name in nameList:
        print(name,'*'*80)
        ui = m_g.load_ui(path + 'DP_'+str(e)+'/timestamp_movie_ratings/' + name  + '.txt')
        m_g.get_UIU(ui, path + 'DP_'+str(e)+'/timestamp_metapath/' + name  + '_uiu.txt')
        m_g.get_UITIU(ui, it, path + 'DP_'+str(e)+'/timestamp_metapath/' + name  + '_uitiu.txt')
        m_g.get_IUI(ui, path + 'DP_'+str(e)+'/timestamp_metapath/' + name  + '_iui.txt')
    # '''

    '''
    # TODO: Lastfm
    path = '../Data/Lastfm/Final_data/'
    m_g = metapathGeneration(unum=223, inum=7708, tnum=2665)  # Ciao

    it = m_g.load_it(path + 'DP_'+str(e)+'/DP_user_taggedartists.txt')
    m_g.get_ITI(it, path + 'DP_'+str(e)+'/timestamp_metapath/iti.txt')

    for name in range(17):
        print(name, '*' * 80)
        ui = m_g.load_ui(path + 'DP_'+str(e)+'/timestamp_user_taggedartists/' +str(name) + '.txt')
        m_g.get_UIU(ui, path + 'DP_'+str(e)+'/timestamp_metapath/' + str(name) + '_uiu.txt')
        m_g.get_UITIU(ui, it, path + 'DP_'+str(e)+'/timestamp_metapath/' + str(name) + '_uitiu.txt')
        m_g.get_IUI(ui, path + 'DP_'+str(e)+'/timestamp_metapath/' + str(name) + '_iui.txt')

# '''
