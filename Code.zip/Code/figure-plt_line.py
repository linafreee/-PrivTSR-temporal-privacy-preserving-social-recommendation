import matplotlib.pyplot as plt
import numpy as np
import math


plt.rc('font',family='Arial',weight='light') #Times New Roman calibri
plt.rcParams["font.weight"]="light"

class plt_parameter_analysis():

    def __init__(self):
        self.path = 'E:/dearling/Papers/1 Learning ability/图/'
        self.font_x = {'family': 'Arial',
                        'color': '#000000',
                        'weight': 'normal',
                       'size': 15,  # 'size': 10,  # 18 for ratio
                        }
        self.font_y1 = {'family': 'Arial',
                   'color': 'fuchsia',
                   'weight': 'normal',
                     'size': 15,  # 'size': 10,
                   }
        self.font_y2 = {'family': 'Arial',
                   'color': 'blue',
                   'weight': 'normal',
                    'size': 15,  # 'size': 10,
                   }

        self.font_y3 = {'family': 'Arial',
                        'color': '#000000',
                        'weight': 'normal',

                        'size': 15,  # for privacy budget  # 'size': 11,  18 for ratio
                        }

        self.font_pb_xy = {'family': 'Arial',
                   'color': '#000000',
                   'weight': 'light',
                   'size': 20,
                   }
        self.font_pb_name = {'family': 'Arial',
                          'color': '#000000',
                          'weight': 'light',
                          'size': 23,
                          }


    def D(self):
        self.CiaoDVD = [1,2,3,4,5]
        self.CiaoDVD_RMSE_mean = [1.8027,1.8640,2.0320,1.9806,2.1524] #mean
        self.CiaoDVD_MAE_mean = [1.1960,1.2841,1.3219,1.3029,1.4409]

        self.CiaoDVD_RMSE=[[1.7693,1.758,1.8038,1.8911,1.7912],[1.8708,1.8697,1.8533,1.873,1.8531],
                           [1.9711,2.321,1.9788,2.0551,1.8342],[1.9682,2.0014,1.9313,2.0212,1.9809],
                           [1.9748,2.3745,2.2404,1.7976,2.3749]]
        self.CiaoDVD_MAE = [[1.1799,1.1689,1.1896,1.2372,1.2043], [1.2831,1.278,1.2887,1.2872,1.2834],
                             [1.31,1.4088,1.3112,1.3453,1.2343], [1.3088,1.3031,1.2773,1.3198,1.3057],
                             [1.3016,1.8467,1.396,1.1751,1.4852]]
        self.CiaoDVD_RMSE_max = [np.max(self.CiaoDVD_RMSE[0]), np.max(self.CiaoDVD_RMSE[1]), np.max(self.CiaoDVD_RMSE[2]),
                                np.max(self.CiaoDVD_RMSE[3]), np.max(self.CiaoDVD_RMSE[4])]
        self.CiaoDVD_RMSE_min = [np.min(self.CiaoDVD_RMSE[0]), np.min(self.CiaoDVD_RMSE[1]), np.min(self.CiaoDVD_RMSE[2]),
                                np.min(self.CiaoDVD_RMSE[3]), np.min(self.CiaoDVD_RMSE[4])]

        self.CiaoDVD_MAE_max = [np.max(self.CiaoDVD_MAE[0]), np.max(self.CiaoDVD_MAE[1]),np.max(self.CiaoDVD_MAE[2]),
                                 np.max(self.CiaoDVD_MAE[3]), np.max(self.CiaoDVD_MAE[4])]
        self.CiaoDVD_MAE_min = [np.min(self.CiaoDVD_MAE[0]), np.min(self.CiaoDVD_MAE[1]), np.min(self.CiaoDVD_MAE[2]),
                                 np.min(self.CiaoDVD_MAE[3]), np.min(self.CiaoDVD_MAE[4])]

        self.Lastfm  = [1,2,3,4,5]
        self.Lastfm_RMSE_mean = [0.2784,1.038,0.9412,0.6292,1.1165]
        self.Lastfm_MAE_mean = [0.0575,0.0704,0.1082,0.0743,0.0615]
        self.Lastfm_RMSE = [[0.2229,0.2958,0.2590,0.3071,0.3074], [1.0141, 0.7088, 2.0772, 0.9959, 0.394],
                             [0.1662,0.4356,1.0681,1.5866,1.4493], [0.137, 0.1228, 0.8965, 1.6288, 0.3607],
                             [2.1362, 1.0102, 0.31, 0.6549, 1.4711]]
        self.Lastfm_MAE = [[0.0539,0.0462,0.0345,0.0647,0.0882], [0.0823,0.0548,0.103,0.0697,0.0423],
                           [0.0432,0.0574,0.0724,0.0866,0.2814], [0.0384,0.0337,0.0877,0.1258,0.0861],
                           [0.0842,0.0553,0.0453,0.0463,0.0764]]
        self.Lastfm_RMSE_max = [np.max(self.Lastfm_RMSE[0]),np.max(self.Lastfm_RMSE[1]),np.max(self.Lastfm_RMSE[2]),
                                np.max(self.Lastfm_RMSE[3]),np.max(self.Lastfm_RMSE[4])]
        self.Lastfm_RMSE_min = [np.min(self.Lastfm_RMSE[0]),np.min(self.Lastfm_RMSE[1]),np.min(self.Lastfm_RMSE[2]),
                                np.min(self.Lastfm_RMSE[3]),np.min(self.Lastfm_RMSE[4])]

        self.Lastfm_MAE_max = [np.max(self.Lastfm_MAE[0]), np.max(self.Lastfm_MAE[1]), np.max(self.Lastfm_MAE[2]),
                                np.max(self.Lastfm_MAE[3]), np.max(self.Lastfm_MAE[4])]
        self.Lastfm_MAE_min = [np.min(self.Lastfm_MAE[0]), np.min(self.Lastfm_MAE[1]), np.min(self.Lastfm_MAE[2]),
                                np.min(self.Lastfm_MAE[3]), np.min(self.Lastfm_MAE[4])]

        # ax = fig.add_subplot(221)
        # plt.bar(self.x, self.RMSE_PrivTSR, width=self.width, label='PrivTSR', color=self.color_list[0],
        #         edgecolor='#000000', yerr=self.std_err_PrivTSR, error_kw=self.error_params)
        #
        fig = plt.figure(figsize=(9, 3), facecolor='w')
        ax = fig.add_subplot(121)
        plt.boxplot(self.CiaoDVD_RMSE, showfliers=True, showbox=True, widths=0, showcaps=True,
                    capprops={'color': 'fuchsia'}, whiskerprops={'color': 'fuchsia'}, boxprops={'color': 'fuchsia'})
        lns1 = ax.plot(self.CiaoDVD, self.CiaoDVD_RMSE_mean, 'D-', linestyle='dashed', markersize=3, c='fuchsia', lw=1.5,
                       alpha=0.8, label='RMSE')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_RMSE_max, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_RMSE_min, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        ax.tick_params(axis='y', colors='fuchsia', direction='in')
        min = 1.6
        max =2.4
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])

        ax2 = ax.twinx()
        plt.boxplot(self.CiaoDVD_MAE, showfliers=True, showbox=True, widths=0, showcaps=True,
                    capprops={'color': 'blue'}, whiskerprops={'color': 'blue'}, boxprops={'color': 'blue'})
        lns2 = ax2.plot(self.CiaoDVD, self.CiaoDVD_MAE_mean, '*-', linestyle='solid', markersize=6, c='blue', lw=1.5,
                        alpha=0.8, label='MAE')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_MAE_max, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_MAE_min, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        ax2.tick_params(axis='y', colors='blue', direction='in')
        min=1
        max=2
        plt.ylim(min, max)
        plt.yticks([min, (min+(min+max) / 2)/2,(min+max) / 2,  ((min+max) / 2+max)/2,max])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1,2,3,4,5],[16,32,64,100,128])
        ax.set_ylabel('RMSE', fontdict=self.font_y1)
        ax2.set_ylabel('MAE', fontdict=self.font_y2)
        ax.set_xlabel(r'$D$', self.font_x)
        plt.xlim(0.5, 5.5)
        plt.title('(a) CiaoDVD', fontsize=15)

        ax = fig.add_subplot(122)
        plt.boxplot(self.Lastfm_RMSE, showfliers=True,showbox=True,widths=0,showcaps=True,
                    capprops={'color':'fuchsia'},whiskerprops={'color':'fuchsia'},boxprops={'color':'fuchsia'})
        lns1 = ax.plot(self.Lastfm, self.Lastfm_RMSE_mean, 'D-', linestyle='dashed', markersize=3, c='fuchsia', lw=1.5,
                       alpha=0.8, label='RMSE')
        plt.scatter(self.Lastfm, self.Lastfm_RMSE_max, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.Lastfm, self.Lastfm_RMSE_min, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        ax.tick_params(axis='y', colors='fuchsia', direction='in')
        min = 0
        max = 2.2
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])

        ax2 = ax.twinx()
        plt.boxplot(self.Lastfm_MAE, showfliers=True,showbox=True,widths=0,showcaps=True,
                    capprops={'color':'blue'},whiskerprops={'color':'blue'},boxprops={'color':'blue'})
        lns2 = ax2.plot(self.Lastfm, self.Lastfm_MAE_mean, '*-', linestyle='solid', markersize=6, c='blue', lw=1.5,
                        alpha=0.8, label='MAE')
        plt.scatter(self.Lastfm, self.Lastfm_MAE_max, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.Lastfm, self.Lastfm_MAE_min, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        ax2.tick_params(axis='y', colors='blue', direction='in')
        min = 0
        max = 0.4
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])
        plt.xticks([1,2,3,4,5],[16,32,64,100,128])

        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs,loc='best')
        ax.tick_params(direction='in')
        ax.set_ylabel('RMSE', fontdict=self.font_y1)
        ax2.set_ylabel('MAE', fontdict=self.font_y2)
        ax.set_xlabel(r'$D$', self.font_x)
        # plt.xlim(np.min(self.Lastfm), np.max(self.Lastfm))
        plt.xlim(0.5, 5.5)
        plt.title('(b) Lastfm', fontsize=15)

        plt.tight_layout()
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                            wspace=0.5, hspace=None)
        plt.savefig('D.png', dpi=600)
        # plt.show()


    def w1(self):
        self.CiaoDVD = [1,2,3,4,5]
        self.CiaoDVD_RMSE_mean = [1.9039,1.9125,1.8640,1.9500,1.9939] #mean
        self.CiaoDVD_MAE_mean = [1.2756,1.2805,1.2841,1.3271,1.3636]

        self.CiaoDVD_RMSE=[[1.9236,1.8946,1.9302,1.8715,1.8995],[1.9261,1.7806,1.937,1.9871,1.9317],
                           [1.8708,1.8697,1.8533,1.873,1.8531],[1.9344,2.038,1.9291,1.9304,1.9183],
                           [1.9563,1.9537,1.9696,1.9826,2.1073]]
        self.CiaoDVD_MAE = [[1.2813,1.269,1.2827,1.2688,1.2764], [1.3013,1.1732,1.3099,1.3192,1.299],
                             [1.2831,1.278,1.2887,1.2872,1.2834], [1.3238,1.3417,1.3203,1.316,1.3337],
                             [1.3334,1.3328,1.3211,1.3229,1.5076]]
        self.CiaoDVD_RMSE_max = [np.max(self.CiaoDVD_RMSE[0]), np.max(self.CiaoDVD_RMSE[1]), np.max(self.CiaoDVD_RMSE[2]),
                                np.max(self.CiaoDVD_RMSE[3]), np.max(self.CiaoDVD_RMSE[4])]
        self.CiaoDVD_RMSE_min = [np.min(self.CiaoDVD_RMSE[0]), np.min(self.CiaoDVD_RMSE[1]), np.min(self.CiaoDVD_RMSE[2]),
                                np.min(self.CiaoDVD_RMSE[3]), np.min(self.CiaoDVD_RMSE[4])]

        self.CiaoDVD_MAE_max = [np.max(self.CiaoDVD_MAE[0]), np.max(self.CiaoDVD_MAE[1]),np.max(self.CiaoDVD_MAE[2]),
                                 np.max(self.CiaoDVD_MAE[3]), np.max(self.CiaoDVD_MAE[4])]
        self.CiaoDVD_MAE_min = [np.min(self.CiaoDVD_MAE[0]), np.min(self.CiaoDVD_MAE[1]), np.min(self.CiaoDVD_MAE[2]),
                                 np.min(self.CiaoDVD_MAE[3]), np.min(self.CiaoDVD_MAE[4])]

        self.Lastfm  = [1,2,3,4,5]
        self.Lastfm_RMSE_mean = [1.3286,0.8761,0.2784,1.6562,0.8308]
        self.Lastfm_MAE_mean = [0.1210,0.0909,0.0575,0.1141,0.1839]
        self.Lastfm_RMSE = [[1.7881,1.8509,1.3542,0.2832,1.3668], [0.1495,1.7570,1.1553,0.9997,0.3192],
                            [0.2229,0.2958,0.2590,0.3071,0.3074], [2.0528,1.9375,1.4683,0.5884,2.2338],
                             [0.2482,0.6201,1.9178,1.0008,0.3673]]
        self.Lastfm_MAE = [[0.1493,0.1459,0.0765,0.1082,0.1252], [0.0399,0.0991,0.0746,0.1611,0.0796],
                           [0.0539,0.0462,0.0345,0.0647,0.0882], [0.1215,0.1158,0.1508,0.0692,0.1134],
                           [0.0615,0.0871,0.3397,0.2581,0.1729]]
        self.Lastfm_RMSE_max = [np.max(self.Lastfm_RMSE[0]),np.max(self.Lastfm_RMSE[1]),np.max(self.Lastfm_RMSE[2]),
                                np.max(self.Lastfm_RMSE[3]),np.max(self.Lastfm_RMSE[4])]
        self.Lastfm_RMSE_min = [np.min(self.Lastfm_RMSE[0]),np.min(self.Lastfm_RMSE[1]),np.min(self.Lastfm_RMSE[2]),
                                np.min(self.Lastfm_RMSE[3]),np.min(self.Lastfm_RMSE[4])]

        self.Lastfm_MAE_max = [np.max(self.Lastfm_MAE[0]), np.max(self.Lastfm_MAE[1]), np.max(self.Lastfm_MAE[2]),
                                np.max(self.Lastfm_MAE[3]), np.max(self.Lastfm_MAE[4])]
        self.Lastfm_MAE_min = [np.min(self.Lastfm_MAE[0]), np.min(self.Lastfm_MAE[1]), np.min(self.Lastfm_MAE[2]),
                                np.min(self.Lastfm_MAE[3]), np.min(self.Lastfm_MAE[4])]

        # ax = fig.add_subplot(221)
        # plt.bar(self.x, self.RMSE_PrivTSR, width=self.width, label='PrivTSR', color=self.color_list[0],
        #         edgecolor='#000000', yerr=self.std_err_PrivTSR, error_kw=self.error_params)
        #
        fig = plt.figure(figsize=(9, 3), facecolor='w')
        ax = fig.add_subplot(121)
        plt.boxplot(self.CiaoDVD_RMSE, showfliers=True, showbox=True, widths=0, showcaps=True,
                    capprops={'color': 'fuchsia'}, whiskerprops={'color': 'fuchsia'}, boxprops={'color': 'fuchsia'})
        lns1 = ax.plot(self.CiaoDVD, self.CiaoDVD_RMSE_mean, 'D-', linestyle='dashed', markersize=3, c='fuchsia', lw=1.5,
                       alpha=0.8, label='RMSE')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_RMSE_max, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_RMSE_min, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        ax.tick_params(axis='y', colors='fuchsia', direction='in')
        min = 1.6
        max = 2.2
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])

        ax2 = ax.twinx()
        plt.boxplot(self.CiaoDVD_MAE, showfliers=True, showbox=True, widths=0, showcaps=True,
                    capprops={'color': 'blue'}, whiskerprops={'color': 'blue'}, boxprops={'color': 'blue'})
        lns2 = ax2.plot(self.CiaoDVD, self.CiaoDVD_MAE_mean, '*-', linestyle='solid', markersize=6, c='blue', lw=1.5,
                        alpha=0.8, label='MAE')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_MAE_max, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_MAE_min, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        ax2.tick_params(axis='y', colors='blue', direction='in')
        min=1
        max=1.6
        plt.ylim(min, max)
        plt.yticks([min, (min+(min+max) / 2)/2,(min+max) / 2,  ((min+max) / 2+max)/2,max])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1,2,3,4,5],[1,2,3,4,5])
        ax.set_ylabel('RMSE', fontdict=self.font_y1)
        ax2.set_ylabel('MAE', fontdict=self.font_y2)
        ax.set_xlabel(r'$w_1$', self.font_x)
        plt.xlim(0.5, 5.5)
        plt.title('(a) CiaoDVD', fontsize=15)

        ax = fig.add_subplot(122)
        plt.boxplot(self.Lastfm_RMSE, showfliers=True,showbox=True,widths=0,showcaps=True,
                    capprops={'color':'fuchsia'},whiskerprops={'color':'fuchsia'},boxprops={'color':'fuchsia'})
        lns1 = ax.plot(self.Lastfm, self.Lastfm_RMSE_mean, 'D-', linestyle='dashed', markersize=3, c='fuchsia', lw=1.5,
                       alpha=0.8, label='RMSE')
        plt.scatter(self.Lastfm, self.Lastfm_RMSE_max, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.Lastfm, self.Lastfm_RMSE_min, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        ax.tick_params(axis='y', colors='fuchsia', direction='in')
        min = 0
        max = 2.4
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])

        ax2 = ax.twinx()
        plt.boxplot(self.Lastfm_MAE, showfliers=True,showbox=True,widths=0,showcaps=True,
                    capprops={'color':'blue'},whiskerprops={'color':'blue'},boxprops={'color':'blue'})
        lns2 = ax2.plot(self.Lastfm, self.Lastfm_MAE_mean, '*-', linestyle='solid', markersize=6, c='blue', lw=1.5,
                        alpha=0.8, label='MAE')
        plt.scatter(self.Lastfm, self.Lastfm_MAE_max, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.Lastfm, self.Lastfm_MAE_min, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        ax2.tick_params(axis='y', colors='blue', direction='in')
        min = 0
        max = 0.4
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])
        plt.xticks([1,2,3,4,5],[1,2,3,4,5])

        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs,loc='best')
        ax.tick_params(direction='in')
        ax.set_ylabel('RMSE', fontdict=self.font_y1)
        ax2.set_ylabel('MAE', fontdict=self.font_y2)
        ax.set_xlabel(r'$w_1$', self.font_x)
        # plt.xlim(np.min(self.Lastfm), np.max(self.Lastfm))
        plt.xlim(0.5, 5.5)
        plt.title('(b) Lastfm', fontsize=15)

        plt.tight_layout()
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                            wspace=0.5, hspace=None)
        plt.savefig('w_1.png', dpi=600)
        # plt.show()


    def w2(self):
        self.CiaoDVD = [1,2,3,4,5]
        self.CiaoDVD_RMSE_mean = [2.4285,2.3860,1.9123,1.8640,1.8975] #mean
        self.CiaoDVD_MAE_mean = [1.8747,1.8388,1.3008,1.2841,1.2714]

        self.CiaoDVD_RMSE=[[2.3521,2.3605,2.5085,2.4612,2.4601],[2.3602,2.4765,2.3685,2.3337,2.3909],
                           [1.8992,1.911,1.9319,1.8954,1.9242],[1.8708,1.8697,1.8533,1.873,1.8531],
                           [1.8849,1.9407,1.9144,1.8643,1.8831]]
        self.CiaoDVD_MAE = [[1.8176,1.8256,1.9261,1.8988,1.9055], [1.83,1.9048,1.8332,1.8004,1.8255],
                             [1.2928,1.2983,1.3081,1.3077,1.297], [1.2831,1.278,1.2887,1.2872,1.2834],
                             [1.2464,1.3259,1.2836,1.2586,1.2426]]
        self.CiaoDVD_RMSE_max = [np.max(self.CiaoDVD_RMSE[0]), np.max(self.CiaoDVD_RMSE[1]), np.max(self.CiaoDVD_RMSE[2]),
                                np.max(self.CiaoDVD_RMSE[3]), np.max(self.CiaoDVD_RMSE[4])]
        self.CiaoDVD_RMSE_min = [np.min(self.CiaoDVD_RMSE[0]), np.min(self.CiaoDVD_RMSE[1]), np.min(self.CiaoDVD_RMSE[2]),
                                np.min(self.CiaoDVD_RMSE[3]), np.min(self.CiaoDVD_RMSE[4])]

        self.CiaoDVD_MAE_max = [np.max(self.CiaoDVD_MAE[0]), np.max(self.CiaoDVD_MAE[1]),np.max(self.CiaoDVD_MAE[2]),
                                 np.max(self.CiaoDVD_MAE[3]), np.max(self.CiaoDVD_MAE[4])]
        self.CiaoDVD_MAE_min = [np.min(self.CiaoDVD_MAE[0]), np.min(self.CiaoDVD_MAE[1]), np.min(self.CiaoDVD_MAE[2]),
                                 np.min(self.CiaoDVD_MAE[3]), np.min(self.CiaoDVD_MAE[4])]

        self.Lastfm  = [1,2,3,4,5]
        self.Lastfm_RMSE_mean = [0.5590,0.7438,0.2784,0.6175,0.6508]
        self.Lastfm_MAE_mean = [0.0259,0.0570,0.0575,0.0878,0.1344]
        self.Lastfm_RMSE = [[0.1048,0.2333,1.0441,0.5753,0.8374], [1.3443, 0.4447,1.2459,0.3726,0.3113],
                            [0.2229,0.2958,0.2590,0.3071,0.3074], [1.2427,0.3008,0.7878,0.4203,0.3361],
                             [0.3836,1.0470,0.7299,0.2183,0.8750]]
        self.Lastfm_MAE = [[0.0103,0.0207,0.0394,0.0256,0.0337], [0.0892,0.0470,0.0682,0.0437,0.0367],
                           [0.0539,0.0462,0.0345,0.0647,0.0882], [0.0969,0.1118,0.0740,0.1070,0.0493],
                           [0.0700,0.1861,0.0971,0.0538,0.2649]]
        self.Lastfm_RMSE_max = [np.max(self.Lastfm_RMSE[0]),np.max(self.Lastfm_RMSE[1]),np.max(self.Lastfm_RMSE[2]),
                                np.max(self.Lastfm_RMSE[3]),np.max(self.Lastfm_RMSE[4])]
        self.Lastfm_RMSE_min = [np.min(self.Lastfm_RMSE[0]),np.min(self.Lastfm_RMSE[1]),np.min(self.Lastfm_RMSE[2]),
                                np.min(self.Lastfm_RMSE[3]),np.min(self.Lastfm_RMSE[4])]

        self.Lastfm_MAE_max = [np.max(self.Lastfm_MAE[0]), np.max(self.Lastfm_MAE[1]), np.max(self.Lastfm_MAE[2]),
                                np.max(self.Lastfm_MAE[3]), np.max(self.Lastfm_MAE[4])]
        self.Lastfm_MAE_min = [np.min(self.Lastfm_MAE[0]), np.min(self.Lastfm_MAE[1]), np.min(self.Lastfm_MAE[2]),
                                np.min(self.Lastfm_MAE[3]), np.min(self.Lastfm_MAE[4])]

        # ax = fig.add_subplot(221)
        # plt.bar(self.x, self.RMSE_PrivTSR, width=self.width, label='PrivTSR', color=self.color_list[0],
        #         edgecolor='#000000', yerr=self.std_err_PrivTSR, error_kw=self.error_params)
        #
        fig = plt.figure(figsize=(9, 3), facecolor='w')
        ax = fig.add_subplot(121)
        plt.boxplot(self.CiaoDVD_RMSE, showfliers=True, showbox=True, widths=0, showcaps=True,
                    capprops={'color': 'fuchsia'}, whiskerprops={'color': 'fuchsia'}, boxprops={'color': 'fuchsia'})
        lns1 = ax.plot(self.CiaoDVD, self.CiaoDVD_RMSE_mean, 'D-', linestyle='dashed', markersize=3, c='fuchsia', lw=1.5,
                       alpha=0.8, label='RMSE')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_RMSE_max, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_RMSE_min, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        ax.tick_params(axis='y', colors='fuchsia', direction='in')
        min = 1.8
        max = 2.6
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])

        ax2 = ax.twinx()
        plt.boxplot(self.CiaoDVD_MAE, showfliers=True, showbox=True, widths=0, showcaps=True,
                    capprops={'color': 'blue'}, whiskerprops={'color': 'blue'}, boxprops={'color': 'blue'})
        lns2 = ax2.plot(self.CiaoDVD, self.CiaoDVD_MAE_mean, '*-', linestyle='solid', markersize=6, c='blue', lw=1.5,
                        alpha=0.8, label='MAE')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_MAE_max, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_MAE_min, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        ax2.tick_params(axis='y', colors='blue', direction='in')
        min=1.2
        max=2
        plt.ylim(min, max)
        plt.yticks([min, (min+(min+max) / 2)/2,(min+max) / 2,  ((min+max) / 2+max)/2,max])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1,2,3,4,5],[1,3,5,7,9])
        ax.set_ylabel('RMSE', fontdict=self.font_y1)
        ax2.set_ylabel('MAE', fontdict=self.font_y2)
        ax.set_xlabel(r'$w_2$', self.font_x)
        plt.xlim(0.5,5.5)
        plt.title('(a) CiaoDVD', fontsize=15)

        ax = fig.add_subplot(122)
        plt.boxplot(self.Lastfm_RMSE, showfliers=True,showbox=True,widths=0,showcaps=True,
                    capprops={'color':'fuchsia'},whiskerprops={'color':'fuchsia'},boxprops={'color':'fuchsia'})
        lns1 = ax.plot(self.Lastfm, self.Lastfm_RMSE_mean, 'D-', linestyle='dashed', markersize=3, c='fuchsia', lw=1.5,
                       alpha=0.8, label='RMSE')
        plt.scatter(self.Lastfm, self.Lastfm_RMSE_max, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.Lastfm, self.Lastfm_RMSE_min, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        ax.tick_params(axis='y', colors='fuchsia', direction='in')
        min = 0
        max = 1.4
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])

        ax2 = ax.twinx()
        plt.boxplot(self.Lastfm_MAE, showfliers=True,showbox=True,widths=0,showcaps=True,
                    capprops={'color':'blue'},whiskerprops={'color':'blue'},boxprops={'color':'blue'})
        lns2 = ax2.plot(self.Lastfm, self.Lastfm_MAE_mean, '*-', linestyle='solid', markersize=6, c='blue', lw=1.5,
                        alpha=0.8, label='MAE')
        plt.scatter(self.Lastfm, self.Lastfm_MAE_max, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.Lastfm, self.Lastfm_MAE_min, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        ax2.tick_params(axis='y', colors='blue', direction='in')
        min = 0
        max = 0.4
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])
        plt.xticks([1,2,3,4,5],[1,3,5,7,9])

        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs,loc='best')
        ax.tick_params(direction='in')
        ax.set_ylabel('RMSE', fontdict=self.font_y1)
        ax2.set_ylabel('MAE', fontdict=self.font_y2)
        ax.set_xlabel(r'$w_2$', self.font_x)
        # plt.xlim(np.min(self.Lastfm), np.max(self.Lastfm))
        plt.xlim(0.5, 5.5)
        plt.title('(b) Lastfm', fontsize=15)

        plt.tight_layout()
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                            wspace=0.5, hspace=None)
        plt.savefig('w_2.png', dpi=600)


    def w3(self):
        self.CiaoDVD = [1,2,3,4,5]
        self.CiaoDVD_RMSE_mean = [1.8640,1.9160,2.0118,2.0952,1.9337] #mean
        self.CiaoDVD_MAE_mean = [1.2841,1.2832,1.2964,1.4618,1.3098]

        self.CiaoDVD_RMSE=[[1.8708,1.8697,1.8533,1.873,1.8531],[1.7878,1.8541,1.9953,1.8949,2.0479],
                           [1.8898,2.1141,1.9728,2.0372,2.0452],[2.0146,2.1229,2.223,2.0454,2.0703],
                           [1.9165,2.0069,1.8882,1.9178,1.9393]]
        self.CiaoDVD_MAE = [[1.2831,1.278,1.2887,1.2872,1.2834], [1.1731,1.2308,1.3581,1.2414,1.4126],
                             [1.2234,1.3179,1.3589,1.3019,1.2798], [1.4181,1.4798,1.5572,1.4128,1.441],
                             [1.2956,1.3866,1.278,1.2892,1.2996]]
        self.CiaoDVD_RMSE_max = [np.max(self.CiaoDVD_RMSE[0]), np.max(self.CiaoDVD_RMSE[1]), np.max(self.CiaoDVD_RMSE[2]),
                                np.max(self.CiaoDVD_RMSE[3]), np.max(self.CiaoDVD_RMSE[4])]
        self.CiaoDVD_RMSE_min = [np.min(self.CiaoDVD_RMSE[0]), np.min(self.CiaoDVD_RMSE[1]), np.min(self.CiaoDVD_RMSE[2]),
                                np.min(self.CiaoDVD_RMSE[3]), np.min(self.CiaoDVD_RMSE[4])]

        self.CiaoDVD_MAE_max = [np.max(self.CiaoDVD_MAE[0]), np.max(self.CiaoDVD_MAE[1]),np.max(self.CiaoDVD_MAE[2]),
                                 np.max(self.CiaoDVD_MAE[3]), np.max(self.CiaoDVD_MAE[4])]
        self.CiaoDVD_MAE_min = [np.min(self.CiaoDVD_MAE[0]), np.min(self.CiaoDVD_MAE[1]), np.min(self.CiaoDVD_MAE[2]),
                                 np.min(self.CiaoDVD_MAE[3]), np.min(self.CiaoDVD_MAE[4])]

        self.Lastfm  = [1,2,3,4,5]
        self.Lastfm_RMSE_mean = [1.4207,0.2784,0.6734,0.8804,1.2176]
        self.Lastfm_MAE_mean = [0.0819,0.0575,0.0901,0.1169,0.1215]
        self.Lastfm_RMSE = [[2.0100,0.9393,1.3645,1.4602,1.3293], [0.2229,0.2958,0.2590,0.3071,0.3074],
                            [0.3989,0.4466,1.7072,0.3418,0.4726], [1.3756,0.4216,1.4862,0.8127,0.3061],
                            [0.7787,1.8174,1.8259,0.2403,1.4255]]
        self.Lastfm_MAE = [[0.0927,0.0611,0.0740,0.0663,0.1156], [0.0539,0.0462,0.0345,0.0647,0.0882],
                           [0.0791,0.0978,0.1242,0.0660,0.0833], [0.0918,0.0840,0.1157,0.2164,0.0765],
                           [0.2351,0.1285,0.1001,0.0511,0.0927]]
        self.Lastfm_RMSE_max = [np.max(self.Lastfm_RMSE[0]),np.max(self.Lastfm_RMSE[1]),np.max(self.Lastfm_RMSE[2]),
                                np.max(self.Lastfm_RMSE[3]),np.max(self.Lastfm_RMSE[4])]
        self.Lastfm_RMSE_min = [np.min(self.Lastfm_RMSE[0]),np.min(self.Lastfm_RMSE[1]),np.min(self.Lastfm_RMSE[2]),
                                np.min(self.Lastfm_RMSE[3]),np.min(self.Lastfm_RMSE[4])]

        self.Lastfm_MAE_max = [np.max(self.Lastfm_MAE[0]), np.max(self.Lastfm_MAE[1]), np.max(self.Lastfm_MAE[2]),
                                np.max(self.Lastfm_MAE[3]), np.max(self.Lastfm_MAE[4])]
        self.Lastfm_MAE_min = [np.min(self.Lastfm_MAE[0]), np.min(self.Lastfm_MAE[1]), np.min(self.Lastfm_MAE[2]),
                                np.min(self.Lastfm_MAE[3]), np.min(self.Lastfm_MAE[4])]

        # ax = fig.add_subplot(221)
        # plt.bar(self.x, self.RMSE_PrivTSR, width=self.width, label='PrivTSR', color=self.color_list[0],
        #         edgecolor='#000000', yerr=self.std_err_PrivTSR, error_kw=self.error_params)
        #
        fig = plt.figure(figsize=(9, 3), facecolor='w')
        ax = fig.add_subplot(121)
        plt.boxplot(self.CiaoDVD_RMSE, showfliers=True, showbox=True, widths=0, showcaps=True,
                    capprops={'color': 'fuchsia'}, whiskerprops={'color': 'fuchsia'}, boxprops={'color': 'fuchsia'})
        lns1 = ax.plot(self.CiaoDVD, self.CiaoDVD_RMSE_mean, 'D-', linestyle='dashed', markersize=3, c='fuchsia', lw=1.5,
                       alpha=0.8, label='RMSE')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_RMSE_max, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_RMSE_min, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        ax.tick_params(axis='y', colors='fuchsia', direction='in')
        min = 1.6
        max = 2.4
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])

        ax2 = ax.twinx()
        plt.boxplot(self.CiaoDVD_MAE, showfliers=True, showbox=True, widths=0, showcaps=True,
                    capprops={'color': 'blue'}, whiskerprops={'color': 'blue'}, boxprops={'color': 'blue'})
        lns2 = ax2.plot(self.CiaoDVD, self.CiaoDVD_MAE_mean, '*-', linestyle='solid', markersize=6, c='blue', lw=1.5,
                        alpha=0.8, label='MAE')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_MAE_max, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.CiaoDVD, self.CiaoDVD_MAE_min, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        ax2.tick_params(axis='y', colors='blue', direction='in')
        min=1.2
        max=1.6
        plt.ylim(min, max)
        plt.yticks([min, (min+(min+max) / 2)/2,(min+max) / 2,  ((min+max) / 2+max)/2,max])
        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs)
        ax.tick_params(direction='in')
        plt.xticks([1,2,3,4,5],[5,10,15,20,25])
        ax.set_ylabel('RMSE', fontdict=self.font_y1)
        ax2.set_ylabel('MAE', fontdict=self.font_y2)
        ax.set_xlabel(r'$w_3$', self.font_x)
        plt.xlim(0.5, 5.5)
        plt.title('(a) CiaoDVD', fontsize=15)

        ax = fig.add_subplot(122)
        plt.boxplot(self.Lastfm_RMSE, showfliers=True,showbox=True,widths=0,showcaps=True,
                    capprops={'color':'fuchsia'},whiskerprops={'color':'fuchsia'},boxprops={'color':'fuchsia'})
        lns1 = ax.plot(self.Lastfm, self.Lastfm_RMSE_mean, 'D-', linestyle='dashed', markersize=3, c='fuchsia', lw=1.5,
                       alpha=0.8, label='RMSE')
        plt.scatter(self.Lastfm, self.Lastfm_RMSE_max, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.Lastfm, self.Lastfm_RMSE_min, c='fuchsia', linewidths=0.3, alpha=0.5, marker='_')
        ax.tick_params(axis='y', colors='fuchsia', direction='in')
        min = 0
        max = 2.2
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])

        ax2 = ax.twinx()
        plt.boxplot(self.Lastfm_MAE, showfliers=True,showbox=True,widths=0,showcaps=True,
                    capprops={'color':'blue'},whiskerprops={'color':'blue'},boxprops={'color':'blue'})
        lns2 = ax2.plot(self.Lastfm, self.Lastfm_MAE_mean, '*-', linestyle='solid', markersize=6, c='blue', lw=1.5,
                        alpha=0.8, label='MAE')
        plt.scatter(self.Lastfm, self.Lastfm_MAE_max, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        plt.scatter(self.Lastfm, self.Lastfm_MAE_min, c='blue', linewidths=0.3, alpha=0.5, marker='_')
        ax2.tick_params(axis='y', colors='blue', direction='in')
        min = 0
        max = 0.4
        plt.ylim(min, max)
        plt.yticks([min, (min + (min + max) / 2) / 2, (min + max) / 2, ((min + max) / 2 + max) / 2, max])
        plt.xticks([1,2,3,4,5],[5,10,15,20,25])

        lns = lns1 + lns2
        labs = [l.get_label() for l in lns]
        ax.legend(lns, labs,loc='best')
        ax.tick_params(direction='in')
        ax.set_ylabel('RMSE', fontdict=self.font_y1)
        ax2.set_ylabel('MAE', fontdict=self.font_y2)
        ax.set_xlabel(r'$w_3$', self.font_x)
        # plt.xlim(np.min(self.Lastfm), np.max(self.Lastfm))
        plt.xlim(0.5, 5.5)
        plt.title('(b) Lastfm', fontsize=15)

        plt.tight_layout()
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None,
                            wspace=0.5, hspace=None)
        plt.savefig('w_3.png', dpi=600)


    def privacy_budget(self):
        self.name=['0.9','0.7','0.5','0.3']
        fig = plt.figure(figsize=(20,  13), facecolor='w')
        # fig = plt.figure(figsize=(12, 6), facecolor='w')
        self.size = 4
        self.x = np.arange(self.size)
        self.total_width, self.n =0.85, 8
        self.width = self.total_width / self.n
        self.x = self.x - (self.total_width - self.width) / 2
        self.color_list =['red',"#FF7F00","yellow",'#00FF00','magenta','#00FFFF','#8B00FF','blue','#778899','RoyalBlue','black']


        # CiaoDVD RMSE *********************************************************************
        self.RMSE_TGSRec=[2.1595,2.2606,2.7683,3.9951]
        self.RMSE_GraphRec= [1.61854,1.67878,1.65438,1.814]
        self.RMSE_diffnet = [1.457,1.6911,2.1237,3.3719]
        self.RMSE_diffnetplus=[1.95146,2.202,2.73228,3.91762]
        self.RMSE_ARSE = [1.9812,2.0932,2.58804,3.88514]
        self.RMSE_PrivSR = [0.65806,0.75958,0.776,0.65274]
        self.RMSE_PrivTSR = [1.86398,1.84486,1.81144,2.44826]

        self.std_err_TGSRec = [0,0,0,0]
        self.std_err_diffnet= [0,0,0,0]
        self.std_err_diffnetplus = [0.00293966,0.000952365,0.003028927,0.003111013]
        self.std_err_ARSE = [0.000917061,0.000254951,0.000556417,0.000914658]
        self.std_err_GraphRec = [0.051283219,0.110232075,0.088218101,0.137986778]
        self.std_err_PrivSR = [0.000450111,0.000830903,0.000725259,0.00040694]
        self.std_err_PrivTSR = [0.00443299,	0.002372467,0.012961119,0.049285623]

        self.error_params = dict(elinewidth=1.5, ecolor=self.color_list[10], capsize=3)


        ax = fig.add_subplot(221)

        plt.bar(self.x, self.RMSE_PrivSR, width=self.width, label='PrivSR', color=self.color_list[0],
                edgecolor='gray', yerr=self.std_err_PrivSR, error_kw=self.error_params)
        plt.bar(self.x + self.width, self.RMSE_GraphRec, width=self.width, label='GraphRec',
                color=self.color_list[1], edgecolor='gray', yerr=self.std_err_GraphRec, error_kw=self.error_params)
        plt.bar(self.x+2 *self.width,self.RMSE_PrivTSR, width=self.width, label='PrivTSR', color=self.color_list[2],
                edgecolor='gray', yerr=self.std_err_PrivTSR, error_kw=self.error_params)
        plt.bar(self.x + 3*self.width, self.RMSE_diffnet, width=self.width, label='DiffNet', color=self.color_list[3],
                edgecolor='gray', yerr=self.std_err_diffnet, error_kw=self.error_params)
        plt.bar(self.x + 4 * self.width, self.RMSE_ARSE, width=self.width, label='ARSE', color=self.color_list[4],
                edgecolor='gray', yerr=self.std_err_ARSE, error_kw=self.error_params)
        plt.bar(self.x +  5* self.width, self.RMSE_diffnetplus, width=self.width, label='DiffNet++',
                color=self.color_list[5],
                edgecolor='gray', yerr=self.std_err_diffnetplus, error_kw=self.error_params)
        plt.bar(self.x + 6 * self.width, self.RMSE_TGSRec, width=self.width, label='TGSRec',
                color=self.color_list[6], edgecolor='gray', yerr=self.std_err_TGSRec, error_kw=self.error_params)
        ax.tick_params(axis='both', direction='in',labelsize=16)
        plt.xticks(np.arange(self.size),self.name)
        l = 0.0
        r = 4.2
        plt.ylim(l, r)
        plt.yticks([0.0,1.0,2.0,3.0,4.0])
        # plt.yticks([l, l + (r - l) / 4, l + (r - l) / 2, r - (r - l) / 4, r])
        # print(l, l + (r - l) / 4, l + (r - l) / 2, r - (r - l) / 4, r)
        ax.set_ylabel('RMSE', fontdict=self.font_pb_xy)
        plt.title('(a) CiaoDVD', fontdict=self.font_pb_name)
        ax.set_xlabel('privacy budget', fontdict=self.font_pb_xy)

        # CiaoDVD MAE ****************************************************************
        self.MAE_TGSRec = [1.7728,1.8976,2.4206,3.6986]
        self.MAE_GraphRec= [1.21724,1.28226,1.28332,1.40856]
        self.MAE_diffnet = [1.2419,1.4931,1.9244,3.2185]
        self.MAE_diffnetplus = [1.73546,1.99988,2.55026,3.7728]
        self.MAE_ARSE = [1.73962,1.88186,2.4091,3.74138]
        self.MAE_PrivSR = [0.37184,0.37682,0.3992,0.39138]
        self.MAE_PrivTSR = [1.28408,1.2287,1.29658,1.64076]

        self.std_err_TGSRec = [0,0,0,0]
        self.std_err_diffnet = [0,0,1.11022E-16,0]
        self.std_err_diffnetplus = [0.002999933,0.000997697,0.002991755,0.003131453]
        self.std_err_ARSE = [0.001463011,0.0002502,0.000527257,0.000926499]
        self.std_err_GraphRec = [0.051255913,0.113034183,0.086635151,0.140047769]
        self.std_err_PrivSR = [5.09902E-05,5.83095E-05,5.47723E-05,5.83095E-05]
        self.std_err_PrivTSR = [0.001863706,0.002761702,0.014951936,0.031553932]

        ax = fig.add_subplot(223)

        plt.bar(self.x, self.MAE_PrivSR, width=self.width, label='PrivSR', color=self.color_list[0],
                edgecolor='gray', yerr=self.std_err_PrivSR, error_kw=self.error_params)
        plt.bar(self.x + self.width, self.MAE_GraphRec, width=self.width, label='GraphRec',
                color=self.color_list[1], edgecolor='gray', yerr=self.std_err_GraphRec, error_kw=self.error_params)
        plt.bar(self.x+2 *self.width,self.MAE_PrivTSR, width=self.width, label='PrivTSR', color=self.color_list[2],
                edgecolor='gray', yerr=self.std_err_PrivTSR, error_kw=self.error_params)
        plt.bar(self.x + 3*self.width, self.MAE_diffnet, width=self.width, label='DiffNet', color=self.color_list[3],
                edgecolor='gray', yerr=self.std_err_diffnet, error_kw=self.error_params)
        plt.bar(self.x + 4 * self.width, self.MAE_ARSE, width=self.width, label='ARSE', color=self.color_list[4],
                edgecolor='gray', yerr=self.std_err_ARSE, error_kw=self.error_params)
        plt.bar(self.x +  5* self.width, self.MAE_diffnetplus, width=self.width, label='DiffNet++',
                color=self.color_list[5],
                edgecolor='gray', yerr=self.std_err_diffnetplus, error_kw=self.error_params)
        plt.bar(self.x + 6 * self.width, self.MAE_TGSRec, width=self.width, label='TGSRec',
                color=self.color_list[6], edgecolor='gray', yerr=self.std_err_TGSRec, error_kw=self.error_params)

        ax.tick_params(axis='both', direction='in',labelsize=16)
        plt.xticks(np.arange(self.size), self.name)
        l = 0.0
        r = 4.0
        plt.ylim(l, r)
        plt.yticks([l, l + (r - l) / 4, l + (r - l) / 2, r - (r - l) / 4, r])
        # print(l, l + (r - l) / 4, l + (r - l) / 2, r - (r - l) / 4, r)
        ax.set_ylabel('MAE', fontdict=self.font_pb_xy)
        ax.set_xlabel(r'privacy budget', fontdict=self.font_pb_xy)


        # Lastfm RMSE ******************************METRICS***************************************
        self.RMSE_TGSRec=[4.8716,6.0906,8.4371,13.9863]
        self.RMSE_diffnet = [4.0571,5.3983,7.7776,13.2221]
        self.RMSE_diffnetplus=[4.66432,5.93734,8.3873,13.78958]
        self.RMSE_ARSE = [4.64426,5.99006,8.35942,13.79674]
        self.RMSE_GraphRec = [1.59338,1.54322,1.7458,1.7515]
        self.RMSE_PrivSR = [1.006,0.8734,0.94526,0.93376]
        self.RMSE_PrivTSR = [0.27844,0.3902,0.37294,0.59542]

        self.std_err_TGSRec = [0,0,0,0]
        self.std_err_diffnet = [0,0,0,8.88178E-16]
        self.std_err_diffnetplus = [0.004708121,0.002563123,0.00307376,0.003542796]
        self.std_err_ARSE = [0.000335559,0.000305941,0.000315278,0.000430813]
        self.std_err_GraphRec = [0.043433206,0.026819012,0.138817304,0.078226063]
        self.std_err_PrivSR = [0.030437789,0.035636849,0.048213251,0.077572673]
        self.std_err_PrivTSR = [0.01646823,0.118699191,0.088051386,0.17848144]

        ax = fig.add_subplot(222)
        plt.bar(self.x, self.RMSE_PrivSR, width=self.width, label='PrivSR', color=self.color_list[0],
                edgecolor='gray', yerr=self.std_err_PrivSR, error_kw=self.error_params)
        plt.bar(self.x + self.width, self.RMSE_GraphRec, width=self.width, label='GraphRec',
                color=self.color_list[1], edgecolor='gray', yerr=self.std_err_GraphRec, error_kw=self.error_params)
        plt.bar(self.x+2 *self.width,self.RMSE_PrivTSR, width=self.width, label='PrivTSR', color=self.color_list[2],
                edgecolor='gray', yerr=self.std_err_PrivTSR, error_kw=self.error_params)
        plt.bar(self.x + 3*self.width, self.RMSE_diffnet, width=self.width, label='DiffNet', color=self.color_list[3],
                edgecolor='gray', yerr=self.std_err_diffnet, error_kw=self.error_params)
        plt.bar(self.x + 4 * self.width, self.RMSE_ARSE, width=self.width, label='ARSE', color=self.color_list[4],
                edgecolor='gray', yerr=self.std_err_ARSE, error_kw=self.error_params)
        plt.bar(self.x +  5* self.width, self.RMSE_diffnetplus, width=self.width, label='DiffNet++',
                color=self.color_list[5],
                edgecolor='gray', yerr=self.std_err_diffnetplus, error_kw=self.error_params)
        plt.bar(self.x + 6 * self.width, self.RMSE_TGSRec, width=self.width, label='TGSRec',
                color=self.color_list[6], edgecolor='gray', yerr=self.std_err_TGSRec, error_kw=self.error_params)

        ax.tick_params(axis='both', direction='in',labelsize=16)
        plt.xticks(np.arange(self.size),self.name)
        l=0.0
        r=14.2
        plt.ylim(l, r)
        plt.yticks([l, l+(r-l)/4, l+(r-l)/2, r-(r-l)/4, r])
        # print(l, l+(r-l)/4, l+(r-l)/2, r-(r-l)/4, r)
        # plt.yticks([1,4.25,7.5,10.75,14])
        ax.set_ylabel('RMSE', fontdict=self.font_pb_xy)
        plt.title('(b) Lastfm',fontdict=self.font_pb_name)
        ax.set_xlabel(r'privacy budget', fontdict=self.font_pb_xy)

        # Lastfm MAE ****************************************************************
        self.MAE_TGSRec = [4.6231,5.88,8.2593,13.8303]
        self.MAE_diffnet = [3.9053,5.2855,7.6847,13.1703]
        self.MAE_diffnetplus = [4.5166,5.83352,8.29824,13.7376]
        self.MAE_ARSE = [4.49494,5.88564,8.26708,13.74508]
        self.MAE_GraphRec = [1.18666,1.13636,1.30942,1.3185]
        self.MAE_PrivSR = [0.35494,0.30902,0.33802,0.40768]
        self.MAE_PrivTSR = [0.0575,0.06166,0.07992,0.07526]

        self.std_err_TGSRec = [0,0,0,0]
        self.std_err_GraphRec= [0.042094187,0.02657895,0.12164108,0.072083126]
        self.std_err_diffnet = [2.22045E-16,0,4.44089E-16,8.88178E-16]
        self.std_err_diffnetplus = [0.004822966,0.002690427,0.0030693,0.003584829]
        self.std_err_ARSE = [0.000345832,0.000304302,0.000336749,0.000428252]
        self.std_err_PrivSR = [0.001807927,0.001558653,0.002164116,0.001641158]
        self.std_err_PrivTSR = [0.009121349,0.009351289,0.022741293,0.016778874]

        ax = fig.add_subplot(224)
        plt.bar(self.x, self.MAE_PrivSR, width=self.width, label='PrivSR', color=self.color_list[0],
                edgecolor='gray', yerr=self.std_err_PrivSR, error_kw=self.error_params)
        plt.bar(self.x + self.width, self.MAE_GraphRec, width=self.width, label='GraphRec',
                color=self.color_list[1], edgecolor='#000000', yerr=self.std_err_GraphRec, error_kw=self.error_params)
        plt.bar(self.x+2 *self.width,self.MAE_PrivTSR, width=self.width, label='PrivTSR', color=self.color_list[2],
                edgecolor='gray', yerr=self.std_err_PrivTSR, error_kw=self.error_params)
        plt.bar(self.x + 3*self.width, self.MAE_diffnet, width=self.width, label='DiffNet', color=self.color_list[3],
                edgecolor='gray', yerr=self.std_err_diffnet, error_kw=self.error_params)
        plt.bar(self.x + 4 * self.width, self.MAE_ARSE, width=self.width, label='ARSE', color=self.color_list[4],
                edgecolor='gray', yerr=self.std_err_ARSE, error_kw=self.error_params)
        plt.bar(self.x +  5* self.width, self.MAE_diffnetplus, width=self.width, label='DiffNet++',
                color=self.color_list[5],
                edgecolor='gray', yerr=self.std_err_diffnetplus, error_kw=self.error_params)
        plt.bar(self.x + 6 * self.width, self.MAE_TGSRec, width=self.width, label='TGSRec',
                color=self.color_list[6], edgecolor='gray', yerr=self.std_err_TGSRec, error_kw=self.error_params)

        ax.tick_params(axis='both', direction='in',labelsize=16)
        plt.xticks(np.arange(self.size), self.name)
        l = 0.0
        r = 14.0
        plt.ylim(l, r)
        plt.yticks([l, l + (r - l) / 4, l + (r - l) / 2, r - (r - l) / 4, r])
        # print(l, l + (r - l) / 4, l + (r - l) / 2, r - (r - l) / 4, r)
        ax.set_ylabel('MAE', fontdict=self.font_pb_xy)
        ax.set_xlabel(r'privacy budget', fontdict=self.font_pb_xy)

        plt.legend(loc =(-0.75,-0.45),ncol=4,fontsize=23)  #
        # plt.tight_layout()
        plt.subplots_adjust(left=0.05, bottom=0.2, right=0.97, top=0.95,
                            wspace=0.2, hspace=0.2)
        plt.savefig('privacy_budget.png')
        plt.show()


    def extension(self):
        self.name=['CiaoDVD-RMSE','CiaoDVD-MAE','Lastfm-RMSE','Lastfm-MAE']
        fig = plt.figure(figsize=(8, 4), facecolor='w')
        self.size = 4
        self.x = np.arange(self.size)
        self.total_width, self.n = 0.6, 7
        self.width = self.total_width / self.n
        self.x = self.x - (self.total_width - self.width) / 2
        self.color_list =["#FF0000","#FF7F00","yellow",'#00FF00','#00FFFF','magenta','RoyalBlue']

        # CiaoDVD RMSE *********************************************************************
        self.extension_1 =[0.4130,	0.3573,0.4146,0.3590]
        self.extension_2A =[0.4382,0.3673,0.4281,0.3626]
        self.extension_2B=[0.4240,0.3584,0.4040,0.3421]
        self.extension_3=[0.4076,0.3492,0.3983,0.3339]
        self.extension_4=[0.4565,0.4164,0.4247,0.3764]
        self.extension_5=[0.4262,0.3618,0.4094,0.3339]
        self.diffnetplus=[0.3968,0.3343,0.3897,0.3217]

        ax = fig.add_subplot(111)
        plt.bar(self.x + 6 * self.width, self.extension_1, width=self.width, label='extension_1',color=self.color_list[6],edgecolor='#000000')
        plt.bar(self.x + 5 * self.width, self.extension_2A, width=self.width, label='extension_2A',color=self.color_list[5],edgecolor='#000000')
        plt.bar(self.x + 4 * self.width, self.extension_2B, width=self.width, label='extension_2B',color=self.color_list[4],edgecolor='#000000')
        plt.bar(self.x + 3 * self.width, self.extension_3, width=self.width, label='extension_3',color=self.color_list[3],edgecolor='#000000')
        plt.bar(self.x + 2 * self.width, self.extension_4, width=self.width, label='extension_4',color=self.color_list[2],edgecolor='#000000')
        plt.bar(self.x + self.width, self.extension_5, width=self.width, label='extension_5',color=self.color_list[1],edgecolor='#000000')
        plt.bar(self.x , self.diffnetplus, width=self.width, label='deepCDM',color=self.color_list[0],edgecolor='#000000')
        ax.tick_params(axis='y', direction='in')
        plt.xticks(np.arange(self.size),self.name)
        plt.ylim(0.3, 0.5)
        plt.yticks([0.30, 0.35,0.40,0.45,0.50])

        plt.legend(loc =0,ncol=4)
        plt.tight_layout()
        plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=0.6, hspace=0.6)
        plt.savefig('extension.png', dpi=600)
        plt.show()

if __name__ == '__main__':
    p = plt_parameter_analysis()
    # p.D()
    # p.w1()
    # p.w2()
    # p.w3()
    p.privacy_budget()
    # p.extension()
