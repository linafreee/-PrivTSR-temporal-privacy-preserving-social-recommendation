import os

train_rate = 0.8

e=0.3
dim = 64
win_size = 3
walk_len = 5
num_walk = 25


'''
#TODO: Ciao
timestamp_list=['2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013']
metapaths = ['uiu', 'uitiu', 'iui']
for timestamp in timestamp_list:
	for metapath in metapaths:
		input_file = '../Data/CiaoDVD/Final_data/DP_'+str(e)+'/timestamp_metapath/' + timestamp+'_'+metapath + '.txt'
		print(input_file)
		output_file = '../Data/CiaoDVD/Final_data/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/' + timestamp+'_'+metapath + '_embedding.txt'

		cmd = 'deepwalk --format edgelist --input ' + input_file + ' --output ' + output_file + \
			  ' --walk-length ' + str(walk_len) + ' --window-size ' + str(win_size) + ' --number-walks '\
			   + str(num_walk) + ' --representation-size ' + str(dim)  #Linux


		print(cmd)
		os.system(cmd)

input_file = '../Data/CiaoDVD/Final_data/DP_'+str(e)+'/timestamp_metapath/DP_trust.txt'  # split with ' '
output_file = '../Data/CiaoDVD/Final_data/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/trust_embedding.txt'

cmd = 'deepwalk --format edgelist --input ' + input_file + ' --output ' + output_file + \
	  ' --walk-length ' + str(walk_len) + ' --window-size ' + str(win_size) + ' --number-walks ' \
	  + str(num_walk) + ' --representation-size ' + str(dim)  # Linux

print(cmd)
os.system(cmd)


input_file = '../Data/CiaoDVD/Final_data/DP_'+str(e)+'/timestamp_metapath/iti.txt'
output_file = '../Data/CiaoDVD/Final_data/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/iti_embedding.txt'

cmd = 'deepwalk --format edgelist --input ' + input_file + ' --output ' + output_file + \
	  ' --walk-length ' + str(walk_len) + ' --window-size ' + str(win_size) + ' --number-walks ' \
	  + str(num_walk) + ' --representation-size ' + str(dim)  # Linux

print(cmd)
os.system(cmd)
'''

# '''
#TODO: Lastfm
metapaths = ['uiu', 'uitiu', 'iui']

for timestamp in range(17):
	for metapath in metapaths:
		input_file = '../Data/Lastfm/Final_data/DP_'+str(e)+'/timestamp_metapath/' + str(timestamp)+'_'+metapath + '.txt'
		output_file = '../Data/Lastfm/Final_data/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/' + str(timestamp)+'_'+metapath + '_embedding.txt'

		cmd = 'deepwalk --format edgelist --input ' + input_file + ' --output ' + output_file + \
			  ' --walk-length ' + str(walk_len) + ' --window-size ' + str(win_size) + ' --number-walks '\
			   + str(num_walk) + ' --representation-size ' + str(dim)  #Linux


		print(cmd)
		os.system(cmd)


input_file = '../Data/Lastfm/Final_data/DP_'+str(e)+'/timestamp_metapath/DP_user_friends.txt'
output_file = '../Data/Lastfm/Final_data/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/trust_embedding.txt'

cmd = 'deepwalk --format edgelist --input ' + input_file + ' --output ' + output_file + \
	  ' --walk-length ' + str(walk_len) + ' --window-size ' + str(win_size) + ' --number-walks ' \
	  + str(num_walk) + ' --representation-size ' + str(dim)  # Linux

print(cmd)
os.system(cmd)


input_file = '../Data/Lastfm/Final_data/DP_'+str(e)+'/timestamp_metapath/iti.txt'
output_file = '../Data/Lastfm/Final_data/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/iti_embedding.txt'

cmd = 'deepwalk --format edgelist --input ' + input_file + ' --output ' + output_file + \
	  ' --walk-length ' + str(walk_len) + ' --window-size ' + str(win_size) + ' --number-walks ' \
	  + str(num_walk) + ' --representation-size ' + str(dim)  # Linux

print(cmd)
os.system(cmd)

# '''

# cd Disk2/Lina/Rec/Code
# python embedding_generation.py