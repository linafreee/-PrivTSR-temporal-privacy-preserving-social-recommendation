# divide datasets; get key words

import numpy as np
import pandas as pd
from collections import defaultdict
import re
import scipy.io as io
import os
import random

# TODO: process the datasets for Lastfm
class data_process():
    def __init__(self):  # self: for this class
        self.path = '../Data/Lastfm/'

    def count_num(self,fl_name):
        self.file=self.path+fl_name
        self.all_users=set()
        self.all_items = set()
        self.all_types = set()
        self.all_timestamps = set()
        self.all_ratings=set()
        li_count=[]
        f = open(self.file, "r")
        lines = f.readlines()
        for line in lines:
            line = line.strip('\n')
            self.all_users.add(int(line.split(',')[0]))  # for users
            self.all_items.add(int(line.split(',')[1]))  # for artist
            self.all_types.add(int(line.split(',')[2]))  # for tags
            if float(line.split(',')[3])>0:
                li_count.append(float(line.split(',')[3]))
            self.all_ratings.add(float(line.split(',')[3]))
            # self.all_timestamps.add((int(line.split(',')[5]),int(line.split(',')[4]))) # for years
            self.all_timestamps.add(int(line.split(',')[4]))  # for years
        print('all_users:',len(self.all_users))
        print('all_items:', len(self.all_items))
        print('all_types:', len(self.all_types))
        print('all_timestamps:', len(self.all_timestamps),sorted(self.all_timestamps))
        print(len(li_count))
        print(self.all_ratings,len(self.all_ratings))


    def pre_data_for_trust(self):
            # 删除user_friends中重复的数据

            self.file = self.path + 'Row_data/user_friends.txt'

            self.pre_list=[]  #
            with open(self.path + 'Final_data/Mid_data/user_friends.txt', 'a+') as self.f_apmr:
                f = open(self.file, "r")
                lines = f.readlines()
                for line in lines:
                    user1, user2 = line.strip().split(',')
                    if (user1, user2) not in self.pre_list:
                        self.f_apmr.write(str(user1)+','+str(user2))
                        self.f_apmr.write('\n')
                        self.pre_list.append((user1, user2))
                        
                        
    def pre_data(self):
        # 将数据整理为需要的格式，并删除2011年5月的数据，由于没有2011年4月的数据

        self.file = self.path + 'Row_data/user_taggedartists.txt'

        with open(self.path + 'Final_data/Mid_data/pre_user_taggedartists.txt', 'a+') as self.f_apmr:
            f = open(self.file, "r")
            lines = f.readlines()
            for line in lines:
                user, item, type,_,month,year = line.strip().split(',')
                if int(year)==1956 or int(year) ==1957 or int( year)==1979:
                    continue
                elif int(year) ==2011 and int(month) ==5:
                    continue
                else:
                    self.f_apmr.write(str(user)+','+str(item)+','+str(type)+','+str(month)+','+str(year))
                    self.f_apmr.write('\n')

    def change_timestamps(self):
        self.li_timestamp=[(2005, 8), (2005, 9), (2005, 10), (2005, 11), (2005, 12), (2006, 1), (2006, 2), (2006, 3), (2006, 4),
         (2006, 5), (2006, 6), (2006, 7), (2006, 8), (2006, 9), (2006, 10), (2006, 11), (2006, 12), (2007, 1),
         (2007, 2), (2007, 3), (2007, 4), (2007, 5), (2007, 6), (2007, 7), (2007, 8), (2007, 9), (2007, 10), (2007, 11),
         (2007, 12), (2008, 1), (2008, 2), (2008, 3), (2008, 4), (2008, 5), (2008, 6), (2008, 7), (2008, 8), (2008, 9),
         (2008, 10), (2008, 11), (2008, 12), (2009, 1), (2009, 2), (2009, 3), (2009, 4), (2009, 5), (2009, 6),
         (2009, 7), (2009, 8), (2009, 9), (2009, 10), (2009, 11), (2009, 12), (2010, 1), (2010, 2), (2010, 3),
         (2010, 4), (2010, 5), (2010, 6), (2010, 7), (2010, 8), (2010, 9), (2010, 10), (2010, 11), (2010, 12),
         (2011, 1), (2011, 2), (2011, 3)]

        self.file = self.path +'Final_data/Mid_data/pre_user_taggedartists.txt'

        with open(self.path + 'Final_data/Mid_data/changet_user_taggedartists.txt', 'a+') as self.f_apmr:
            f = open(self.file, "r")
            lines = f.readlines()
            for line in lines:
                user, item, type, month, year = line.strip().split(',')
                self.f_apmr.write(str(user) + ',' + str(item) + ',' + str(type) + ',' + str(int(self.li_timestamp.index((int(year),int(month)))/4)))
                self.f_apmr.write('\n')


    def select_user(self):
        # remain: the timestamps corresponding to the users>=3
        self.file = self.path + 'Final_data/Mid_data/changet_user_taggedartists.txt'
        self.dic_users_timestamps1 = defaultdict(set)
        self.dic_users_timestamps2 = defaultdict(set)
        self.dic_users_timestamps3 = defaultdict(set)
        f = open(self.file, "r")
        lines = f.readlines()
        self.set_users_all=set()
        for line in lines:
            line = line.strip('\n')
            self.set_users_all.add(int(line.split(',')[0]))
            if 0<=int(line.split(',')[3])<=8:
                self.dic_users_timestamps1[int(line.split(',')[0])].add(line.split(',')[3])
            if 9<=int(line.split(',')[3])<=11:
                self.dic_users_timestamps2[int(line.split(',')[0])].add(line.split(',')[3])
            if 12<=int(line.split(',')[3])<=16:
                self.dic_users_timestamps3[int(line.split(',')[0])].add(line.split(',')[3])
        # print(self.set_users_all)
        # print('all_users_count:',len(self.set_users_all))

        self.li_users_su = set()
        for user in self.set_users_all:
            if len(self.dic_users_timestamps1[user]) >=1 and len(self.dic_users_timestamps3[user]) >=1:
                self.li_users_su.add(user)

        self.li_users_su=list(self.li_users_su)
        self.li_users_su.sort()
        # print('self.li_users_su:',self.li_users_su)


    def generate_trust_data(self):
        self.trust_data = pd.read_table(self.path + 'Row_data/user_friends.txt', sep=',', header=None)
        self.trust_data.columns = [['user0', 'user1']]

        self.li_all= []  # 存放需要的用户，用户之间的关系
        k = 0  # 用户关系的数量
        for i in range(len(self.trust_data)):  # 遍历所有用户关系
            # print(all_data.iloc[i])
            # 如果对应的用户0与用户1都是我们需要的用户
            if (self.trust_data.iloc[i]['user0'].values[0] in self.li_users_su) & (self.trust_data.iloc[i]['user1'].values[0] in self.li_users_su):
                # print(all_data.iloc[i])    # 显示打印
                k = k + 1
                # print(k)
                # print(all_data.iloc[i].values.tolist())
                self.li_all.append(self.trust_data.iloc[i].values.tolist())  # 保存 ['用户0', '用户1', '关系']

        self.df_all = pd.DataFrame(self.li_all)  # list 转为 DataFrame

        self.df_all.columns = [['user0', 'user1']]  # 1281， 自己提取出来的需要地用户之间的关系
        self.li_users_gtd = self.df_all[['user0']].values.reshape(1, -1)[0].tolist() + \
                            self.df_all[['user1']].values.reshape(1, -1)[0].tolist()  # 2562
        self.li_users_gtd = list(set(self.li_users_gtd))  # 187， 一开始307个用户，挑选完后只剩下187个用户
        self.li_users_gtd = sorted(self.li_users_gtd)  # 用户排序
        x_dic = {}  # 存放用户新的编号
        kk = 0  # 新编号
        for x in self.li_users_gtd:  # 遍历每一个用户的旧编号
            x_dic[x] = kk  # 将新编号存入字典;dic[旧编号int]:新编号int
            kk = kk + 1  # 新编号+1
        self.new_df_all = self.df_all.replace(x_dic)  # 旧编号替换新编号后的关系

        with open(self.path + 'Final_data/user_friends.txt', 'w') as outfile:
            for i in range(len(self.new_df_all)):
                user0, user1= self.new_df_all.iloc[i].tolist()
                # print(user0, user1, relation)
                outfile.write(str(user0) + ',' + str(user1)  + ','+str(1)) #uu[i][j]两个用户共同的business数
                outfile.write('\n')


        # print('self.li_users_gtd:', self.li_users_gtd)
        # print('x_dic',x_dic)
        # fw = open(self.path + 'Final_data/x_dic.txt', 'w+')
        # fw.write(str(x_dic))  # 把字典转化为str
        print(len(x_dic))

        return x_dic


    def generat_data(self,x_dic):
        # delete some users; use the remain_users

        self.file = self.path + 'Final_data/Mid_data/changet_user_taggedartists.txt'
        # 用户筛选,用户编号重写
        with open(self.path + 'Final_data/Mid_data/user_taggedartists0.txt', 'a+') as self.f_apmr:
            f = open(self.file, "r")
            lines = f.readlines()
            for line in lines:
                user, item, type,time = line.strip().split(',')
                if int(user) in self.li_users_gtd:
                    self.f_apmr.write(str(x_dic[int(user)])+','+str(item)+','+str(type)+','+str(time))
                    self.f_apmr.write('\n')

        #保留的物品记录
        self.li_item_gd = []
        self.file1 = self.path + 'Final_data/Mid_data/user_taggedartists0.txt'
        f1 = open(self.file1, "r")
        lines1 = f1.readlines()
        for line in lines1:
            user, item, type, time = line.strip().split(',')
            self.li_item_gd.append(item)
        self.li_item_gd = list(set(self.li_item_gd))
        self.li_item_gd = sorted(self.li_item_gd)
        kk = 0  # 新编号
        item_dic={}
        for i in self.li_item_gd:  # 遍历每一个用户的旧编号
            item_dic[i] = kk  # 将新编号存入字典;dic[旧编号]str:新编号int
            kk = kk + 1  # 新编号+1
        # fw = open(self.path + 'Final_data/item_dic.txt', 'w')
        # fw.write(str(item_dic))  # 把字典转化为str
        print(len(item_dic))

        #物品重编号
        self.file2 = self.path + 'Final_data/Mid_data/user_taggedartists0.txt'
        with open(self.path + 'Final_data/Mid_data/user_taggedartists1.txt', 'a+') as self.f_apmr2:
            f2 = open(self.file2, "r")
            lines2 = f2.readlines()
            for line in lines2:
                user, item, type,  time = line.strip().split(',')
                self.f_apmr2.write(
                        str(user) + ',' + str(item_dic[item]) + ',' + str(type) + ',' +  str(time))
                self.f_apmr2.write('\n')

    def generat_data1(self):

        # 类型重编号
        self.li_type_gd = []
        self.file1 = self.path + 'Final_data/Mid_data/user_taggedartists1.txt'
        f1 = open(self.file1, "r")
        lines1 = f1.readlines()
        for line in lines1:
            user, item, type, time = line.strip().split(',')
            self.li_type_gd.append(type)
        self.li_type_gd = list(set(self.li_type_gd))
        self.li_type_gd = sorted(self.li_type_gd)
        kk = 0  # 新编号
        type_dic = {}
        for i in self.li_type_gd:  # 遍历每一个用户的旧编号
            type_dic[i] = kk  # 将新编号存入字典;dic[旧编号]str:新编号int
            kk = kk + 1  # 新编号+1
        # fw = open(self.path + 'Final_data/item_dic.txt', 'w')
        # fw.write(str(item_dic))  # 把字典转化为str
        print(len(type_dic))


        self.file2 = self.path + 'Final_data/Mid_data/user_taggedartists1.txt'
        with open(self.path + 'Final_data/Mid_data/user_taggedartists2.txt', 'a+') as self.f_apmr2:
            f2 = open(self.file2, "r")
            lines2 = f2.readlines()
            for line in lines2:
                user, item, type, time = line.strip().split(',')
                self.f_apmr2.write(
                    str(user) + ',' + str(item) + ',' + str(type_dic[type]) + ',' + str(time))
                self.f_apmr2.write('\n')

        self.arr_rate = np.zeros((num_timestamp, num_users, num_items))  # for CiaoDVD;timestamps:users:items=rate
        self.arr_mask = np.zeros((num_timestamp, num_users, num_items))  # for CiaoDVD;timestamps:users:items=types


        self.fl_s0 = open(self.path + 'Final_data/Mid_data/user_taggedartists2.txt', "r")
        self.lines_s0 = self.fl_s0.readlines()

        for line in self.lines_s0:
            self.user,self.item, self.type, self.timestamp = line.strip().split(',')
            self.arr_rate[int(self.timestamp)][int(self.user)][int(self.item)] += 1

        max = self.arr_rate.max()
        min = self.arr_rate.min()
        print(max,min)

        # self.arr_rate=(self.arr_rate-min)/(max-min)
        self.arr_rate = self.arr_rate/10

        with open(self.path + 'Final_data/user_taggedartists.txt', 'a+') as self.f_apmr2:
            for line in self.lines_s0:
                self.user, self.item, self.type, self.timestamp = line.strip().split(',')
                # if self.arr_rate[int(self.timestamp)][int(self.user)][int(self.item)]>1:
                #     print(self.arr_rate[int(self.timestamp)][int(self.user)][int(self.item)])
                self.f_apmr2.write( str(self.user) + ',' + str(self.item) + ',' + str(self.type) + ',' + str(self.arr_rate[int(self.timestamp)][int(self.user)][int(self.item)])+','+str(self.timestamp))
                self.f_apmr2.write('\n')

class DP_data():
    def __init__(self):
        self.path = '../Data/Lastfm/'

    def count_score(self, fl_name, str):
        self.file = fl_name
        self.li_score_type = [0 for i in range(num_types)]
        self.li_score_item = [0 for i in range(num_items)]
        self.li_score_trust = [0 for i in range(num_users)]
        # print(self.li_score_type)

        f = open(self.file, "r")
        lines = f.readlines()
        for line in lines:
            # print(line)
            if str == 'type':
                _, _, type, _, _ = line.strip().split(',')
                self.li_score_type[int(type) - 1] += 1
            if str == 'item':
                _, item, _, _, _ = line.strip().split(',')
                self.li_score_item[int(item)] += 1
            if str == 'trust':
                u1, u2, _ = line.strip().split(',')
                self.li_score_trust[int(u2)] += 1

        if str == 'type':
            self.li_score = self.li_score_type
        if str == 'item':
            self.li_score = self.li_score_item
        if str == 'trust':
            self.li_score = self.li_score_trust

        # print('li_score:', self.li_score)
        return self.li_score

    def expMechanism(self, scores, e, sensitivity):
        probability0 = []
        probability1 = []
        for score in scores:
            probability0.append(np.exp(0.5 * e * score / sensitivity))
        sum = np.sum(probability0)
        # 归一化处理
        for i in range(len(probability0)):
            probability1.append(probability0[i] / sum)
        # print("when epslion={},probability1:".format(e))
        # print(probability1)

        random.seed()
        r = random.randint(0, 99) / 100
        # print(r)
        sum_exp = 0
        for j in range(len(probability1)):
            sum_exp = sum_exp + probability1[j]
            if (sum_exp > r):
                rand = j
                # print(j)
                break
        rand = j
        return rand

    def generate_DP_data(self):
        self.li_rec = list(range(0, num_records))
        self.li_item_s = random.sample(self.li_rec, int(0.3 * num_records))
        self.li_type_s = random.sample(self.li_rec, int(0.3 * num_records))
        self.li_trust_s = random.sample(self.li_rec, int(0.3 * num_records))

        sensitivity_item = 1
        sensitivity_type = 1
        sensitivity_trust = 1

        scores_item = self.count_score(self.path + 'Final_data/user_taggedartists.txt', 'item')
        scores_type = self.count_score(self.path + 'Final_data/user_taggedartists.txt', 'type')
        scores_trust = self.count_score(self.path + 'Final_data/user_friends.txt', 'trust')

        print(self.path)
        with open(self.path + 'Final_data/DP_' + str(e) + '/DP_user_taggedartists.txt',
                  'a+') as self.f_rating:
            self.file = self.path + 'Final_data/user_taggedartists.txt'
            self.li_score = []
            f = open(self.file, "r")
            lines = f.readlines()
            i = 0
            for line in lines:
                user, self.item, self.type, rating, time = line.strip().split(',')
                self.rating = float(rating) + np.random.laplace(4.2/ e)
                if i in self.li_item_s:
                    self.item = self.expMechanism(scores_item, e, sensitivity_item)
                if i in self.li_type_s:
                    self.type = self.expMechanism(scores_type, e, sensitivity_type)
                i += 1
                self.f_rating.write(str(user) + ',' + str(self.item) + ',' + str(self.type) + ',' + str(
                    self.rating) + ',' + str(time))
                self.f_rating.write('\n')

        with open(self.path + 'Final_data/DP_' + str(e) + '/DP_user_friends.txt', 'a+') as self.f_trust:
            self.file = self.path + 'Final_data/user_friends.txt'
            self.li_score = []
            f = open(self.file, "r")
            lines = f.readlines()
            i = 0
            for line in lines:
                user1, user2, relation = line.strip().split(',')
                if i in self.li_item_s:
                    self.user2 = self.expMechanism(scores_trust, e, sensitivity_trust)
                i += 1
                self.f_trust.write(str(user1) + ',' + str(user2) + ',' + str(relation))
                self.f_trust.write('\n')


# TODO: divide the datasets
class to_array():
    def __init__(self):
        self.path = '../Data/Lastfm/'

    def divide_data(self):
        # train-vali;train_vali-test
        self.fl_gd = open(self.path + 'Final_data/'+ 'DP_'+str(e)+'/DP_user_taggedartists.txt', "r")  # '+ 'DP_'+str(e)+'/DP_
        self.lines_gd = self.fl_gd.readlines()
        for line in self.lines_gd:
            line = line.strip('\n')
            if 0 <= int(line.split(',')[4]) < 9:
                with open(self.path + 'Final_data/'+ 'DP_'+str(e)+'/DP_user_taggedartists_train.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
                with open(self.path + 'Final_data/'+ 'DP_'+str(e)+'/DP_user_taggedartists_train_valid.txt', 'a+') as self.fl_tv:
                    self.fl_tv.write(line)
                    self.fl_tv.write('\n')
            if 9 <= int(line.split(',')[4]) < 12:
                with open(self.path + 'Final_data/'+ 'DP_'+str(e)+'/DP_user_taggedartists_valid.txt', 'a+') as self.fl_va:
                    self.fl_va.write(line)
                    self.fl_va.write('\n')
                with open(self.path + 'Final_data/'+ 'DP_'+str(e)+'/DP_user_taggedartists_train_valid.txt', 'a+') as self.fl_tv:
                    self.fl_tv.write(line)
                    self.fl_tv.write('\n')
            if 12 <= int(line.split(',')[4]) < 17:
                with open(self.path + 'Final_data/'+ 'DP_'+str(e)+'/DP_user_taggedartists_test.txt', 'a+') as self.fl_te:
                    self.fl_te.write(line)
                    self.fl_te.write('\n')

    def divide_data0(self):
        # train-vali;train_vali-test
        self.fl_gd = open(self.path + 'Final_data/user_taggedartists.txt', "r")  # '+ 'DP_'+str(e)+'/DP_
        self.lines_gd = self.fl_gd.readlines()
        for line in self.lines_gd:
            line = line.strip('\n')
            if 0 <= int(line.split(',')[4]) < 9:
                with open(self.path + 'Final_data/user_taggedartists_train.txt', 'a+') as self.fl_tr:
                    self.fl_tr.write(line)
                    self.fl_tr.write('\n')
                with open(self.path + 'Final_data/user_taggedartists_train_valid.txt', 'a+') as self.fl_tv:
                    self.fl_tv.write(line)
                    self.fl_tv.write('\n')
            if 9 <= int(line.split(',')[4]) < 12:
                with open(self.path + 'Final_data/user_taggedartists_valid.txt', 'a+') as self.fl_va:
                    self.fl_va.write(line)
                    self.fl_va.write('\n')
                with open(self.path + 'Final_data/user_taggedartists_train_valid.txt', 'a+') as self.fl_tv:
                    self.fl_tv.write(line)
                    self.fl_tv.write('\n')
            if 12 <= int(line.split(',')[4]) < 17:
                with open(self.path + 'Final_data/user_taggedartists_test.txt', 'a+') as self.fl_te:
                    self.fl_te.write(line)
                    self.fl_te.write('\n')


    def divide_data_timestamp(self):
        # train-vali;train_vali-test
        self.fl_gd = open(self.path + 'Final_data/'+ 'DP_'+str(e)+'/DP_'+ 'user_taggedartists.txt', "r")
        self.lines_gd = self.fl_gd.readlines()
        for i in range(17):
            for line in self.lines_gd:
                line = line.strip('\n')
                if int(line.split(',')[4]) == i:
                    with open(self.path + 'Final_data/'+ 'DP_'+str(e)+'/timestamp_user_taggedartists/'+str(i)+'.txt', 'a+') as self.fl_tr:
                        self.fl_tr.write(line)
                        self.fl_tr.write('\n')

    def find_min_max(self,t_num,u_num,i_num):

        print(self.arr_rate.max(),self.arr_rate.min())
        return self.arr_rate.max(),self.arr_rate.min()

    def txt_to_array(self,t_num,u_num,i_num):

        self.arr_rate = np.zeros((t_num,u_num,i_num))  # for CiaoDVD;timestamps:users:items=rate
        self.arr_mask = np.zeros((t_num,u_num,i_num))  # for CiaoDVD;timestamps:users:items=types

        self.fl_s0 = open(self.path + 'Final_data/'+ 'DP_'+str(e)+'/DP_user_taggedartists.txt', "r")
        self.lines_s0 = self.fl_s0.readlines()

        for line in self.lines_s0:
            line = line.strip('\n')
            self.timestamp = int(line.split(',')[4])
            self.arr_rate[self.timestamp][int(line.split(',')[0])][int(line.split(',')[1])] += 1

        max=self.arr_rate.max()
        min=self.arr_rate.min()

        li_s0 = ['train', 'valid', 'train_valid', 'test']
        for s0 in li_s0:
            self.fl_s0 = open(self.path + 'Final_data/'+ 'DP_'+str(e)+'/DP_user_taggedartists_' + s0 + '.txt', "r")
            self.lines_s0 = self.fl_s0.readlines()

            for line in self.lines_s0:
                line = line.strip('\n')
                self.timestamp=int(line.split(',')[4])
                self.arr_rate[self.timestamp][int(line.split(',')[0])][int(line.split(',')[1])]+=1
                self.arr_mask[self.timestamp][int(line.split(',')[0])][int(line.split(',')[1])] = 1
            self.arr_rate=(self.arr_rate-min)/(max-min)
            io.savemat(self.path + 'Final_data/'+ 'DP_'+str(e)+'/array_trainvalidtest/'+s0+'.mat', {s0+'_rate': self.arr_rate, s0 + '_mask': self.arr_mask})

class merge_embedding():

    def __init__(self):
        self.path = '../Data/Lastfm/Final_data'

    def merge_user(self):
        self.dic_trust = {}
        self.file_trust = open(self.path + '/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/trust_embedding.txt', "r")
        self.lines_trust = self.file_trust.readlines()
        for line in self.lines_trust[1:]:
            user = line.strip('\n').split(sep=' ')[0]  # str
            self.embedding_str = line.strip('\n').split(sep=' ')[1:]
            self.embedding = [float(x) for x in self.embedding_str]  # list[float]
            self.dic_trust[user]=self.embedding
        # print(self.dic_trust.keys())

        all_time_dict = {}
        for i in range(17):
            print(i,'*'*100)
            self.dic_uiu={}
            self.dic_uitiu={}

            if os.path.exists(self.path + '/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/'+str(i)+'_uiu_embedding.txt') == True:
                self.file_uiu=open(self.path + '/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/'+str(i)+'_uiu_embedding.txt', "r")
                self.lines_uiu = self.file_uiu.readlines()
                for line in self.lines_uiu[1:]:
                    user = line.strip('\n').split(sep=' ')[0]  # str
                    self.embedding_str = line.strip('\n').split(sep=' ')[1:]
                    self.embedding = [float(x) for x in self.embedding_str]  # list[float]
                    self.dic_uiu[user] = self.embedding

            self.file_uitiu = open(self.path + '/DP_'+str(e)+'/tune/timestamp_embedding' +str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/' +str(i) + '_uitiu_embedding.txt', "r")
            self.lines_uitiu = self.file_uitiu.readlines()
            for line in self.lines_uitiu[1:]:
                user = line.strip('\n').split(sep=' ')[0]  # str
                self.embedding_str = line.strip('\n').split(sep=' ')[1:]
                self.embedding = [float(x) for x in self.embedding_str]  # list[float]
                self.dic_uitiu[user] = self.embedding

            # print(list(self.dic_uiu.keys()))
            # print(list(self.dic_uitiu.keys()))
            print(len(self.dic_trust.keys()))
            all_user = set(list(self.dic_uiu.keys()) + list(self.dic_uitiu.keys()) + list(self.dic_trust.keys()))
            # assert (len(all_user) == len(self.dic_trust.keys()))
            # print(all_user)

            all_user_dict = {}
            for k in list(self.dic_trust.keys()):
                if (k in list(self.dic_uiu.keys())) and (k not in list(self.dic_uitiu.keys())):
                    all_user_dict[k] = np.average([self.dic_uiu[k], self.dic_trust[k]], axis = 0)
                if (k not in list(self.dic_uiu.keys())) and (k in list(self.dic_uitiu.keys())):
                    all_user_dict[k] = np.average([self.dic_uitiu[k], self.dic_trust[k]], axis=0)
                if (k in list(self.dic_uiu.keys())) and (k in list(self.dic_uitiu.keys())):
                    all_user_dict[k] = np.average([self.dic_uiu[k], self.dic_uitiu[k], self.dic_trust[k]], axis=0)
                if (k not in list(self.dic_uiu.keys())) and (k not in list(self.dic_uitiu.keys())):
                    all_user_dict[k] = self.dic_trust[k]

            all_user_numpy = np.zeros((num_users, dim))
            for u in all_user_dict.keys():
                all_user_numpy[int(u)] = all_user_dict[u]
            # print(all_user_numpy)
            all_time_dict[str(i)] = all_user_numpy
            # np.save(self.path + '/timestamp_merged_embedding/' + i + '_merge', all_user_numpy)
        io.savemat(self.path + '/DP_'+str(e)+'/tune/all_time_merge'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/all_time_merge_user.mat', all_time_dict)  # dic[timestamp]=array

    def merge_item(self):

        self.dic_iti = {}
        self.file_iti = open(self.path + '/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/iti_embedding.txt', "r")
        self.lines_iti = self.file_iti.readlines()
        for line in self.lines_iti[1:]:
            item = line.strip('\n').split(sep=' ')[0]  # str
            self.embedding_str = line.strip('\n').split(sep=' ')[1:]
            self.embedding = [float(x) for x in self.embedding_str]  # list[float]
            self.dic_iti[item] = self.embedding

        all_time_dict = {}
        all_time_deletion_dict=defaultdict(list)
        for i in range(17):
            # print(i,'*'*100)
            self.dic_iui={}

            self.file_iui = open(self.path + '/DP_'+str(e)+'/tune/timestamp_embedding'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/'+str(i)+'_iui_embedding.txt', "r")
            self.lines_iui = self.file_iui.readlines()
            for line in self.lines_iui[1:]:
                item = line.strip('\n').split(sep=' ')[0]  # str
                self.embedding_str = line.strip('\n').split(sep=' ')[1:]
                self.embedding = [float(x) for x in self.embedding_str]  # list[float]
                self.dic_iui[item] = self.embedding

            # print(list(self.dic_iui.keys()))
            # print(list(self.dic_iti.keys()))
            # print(len(self.dic_iti.keys()))

            # print(len(self.dic_iti.keys()))
            all_item = set(list(self.dic_iui.keys()) + list(self.dic_iti.keys()))
            # print(len(all_item))
            # assert (len(all_item) == len(self.dic_iti.keys()))
            # print(all_user)

            all_item_dict = {}
            for k in range(7708):
                if (str(k) in list(self.dic_iui.keys())) and (str(k) not in list(self.dic_iti.keys())):
                    all_item_dict[str(k)] = self.dic_iui[str(k)]
                    # print('wrong-----------------------------------------------')
                if (str(k) not in list(self.dic_iui.keys())) and (str(k) in list(self.dic_iti.keys())):
                    all_item_dict[str(k)] = self.dic_iti[str(k)]
                if (str(k) in list(self.dic_iui.keys())) and (str(k) in list(self.dic_iti.keys())):
                    all_item_dict[str(k)] = np.average([self.dic_iui[str(k)], self.dic_iti[str(k)]], axis=0)
                if (str(k) not in list(self.dic_iui.keys())) and (str(k) not in list(self.dic_iti.keys())):
                    # print(k)
                    all_time_deletion_dict[i].append(k)

            all_item_numpy = np.random.rand(num_items, dim)
            # print('len',(len(all_item_dict.keys()), len(all_item_dict['0'])))
            for item in all_item_dict.keys():
                all_item_numpy[int(item)] = all_item_dict[item]
            # print(all_item_numpy)
            all_time_dict[str(i)] = all_item_numpy
            # np.save(self.path + '/timestamp_merged_embedding/' + str(i) + '_merge', all_item_numpy)

        # print(all_time_deletion_dict)
        io.savemat(self.path + '/DP_'+str(e)+'/tune/all_time_merge'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/all_time_merge_item.mat', all_time_dict)

    def get_average_merge(self,file_name):
        x = io.loadmat(self.path +'/DP_'+str(e)+'/tune/all_time_merge'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/all_time_merge_'+ file_name+'.mat')
        X=None
        len=17
        for i in range(len):  # 14 for ciao
            if i ==0:
                X=x[str(i)]
                print(x[str(i)].shape)
            else:
                    X+=x[str(i)]
        X=X/len

        # print(X.shape)
        # print(type(X))
        np.save(self.path+'/DP_'+str(e)+'/tune/all_time_merge'+str(dim)+'_'+str(win_size)+'_'+str(walk_len)+'_'+str(num_walk)+'/mean_'+file_name+'.npy', X)


if __name__ == "__main__":
    num_timestamp=17
    num_users=223
    num_items=7708
    num_types=2665
    num_records=52354

    e = 0.3
    dim = 64
    win_size = 3
    walk_len = 5
    num_walk = 25
    print(e,dim,win_size, walk_len, num_walk)

    # class
    d_p=data_process()
    t_a=to_array()
    me=merge_embedding()
    d_d = DP_data()

     # TODO: generate user_taggedartists
    # d_p.pre_data()
    # d_p.change_timestamps()
    # d_p.select_user()
    # x_dic=d_p.generate_trust_data()
    # d_p.generat_data(x_dic)  # ap_movie-ratings
    # d_p.generat_data1()
    # d_p.count_num('Final_data/user_taggedartists.txt')  # 'Final_data/user_taggedartists.txt' Row_data
    # d_p.pre_data_for_trust()

    # TODO: generate DP data and array
    # d_d.generate_DP_data()

    # t_a.divide_data() # to txt;train valid trai/n-valid test
    # t_a.divide_data_timestamp()
    # t_a.txt_to_array(num_timestamp,num_users,num_items)
    # d_p.count_num('Final_data/DP_0.9/DP_user_taggedartists.txt')  #  DP_0.4/DP_

    # TODO: merge embedding
    # me.merge_user()
    # me.merge_item()
    # me.get_average_merge('user')
    # me.get_average_merge('item')







