# 导入数据分析包
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 导入可视化包
import matplotlib.pyplot as plt

from pylab import *

data = pd.read_csv(r'F:\Pycharm\SocialRecommendation\Rec\Data\Lastfm\Final_data\DP_0.9/DP_user_taggedartists.txt ',
                   sep=',', header=None)  # gd_movie-ratings.txt

# CiaoDVD\Final_data\gd_movie-ratings.txt   DP_0.1/DP_gd_movie-ratings.txt
#Lastfm\Final_data\user_taggedartists.txt  DP_0.1/DP_user_taggedartists.txt


rcParams['axes.unicode_minus'] = False

rcParams['font.sans-serif'] = ['Simhei']

rcParams['axes.unicode_minus'] = False
rcParams['font.sans-serif'] = ['Simhei']

# box_3 = data[3]
# li = [box_3]
#
# count = 1
# for i in li:
#     print(count)
#     print(i.value_counts())
#     count += 1

# 诗诗写的 start
# 小于0；0-0.1（大于等于0小于0.1,后同）；0.1-0.2（）；0.2-0.3；0.3-0.4；0.4-0.5；0.5-0.6；
# 0.6-0.7；0.7-0.8；0.8-0.9；0.9-1.0，大于1

results = data[3].tolist()
print(min(results),max(results))
sections = [-1000000, 0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 10000000]
# cuts = pd.cut(pd.array(results), sections, include_lowest=True, right=False)
cuts = pd.cut(np.array(results), sections, include_lowest=True, right=False)
counts = pd.value_counts(cuts).sort_index()

data_count = {"value": counts.index, "value_counts": counts.values}
df_count = pd.DataFrame(data_count).T
# print(df_count)
df=pd.DataFrame(df_count.ix[1]).T

df.to_excel(r'F:\Pycharm\SocialRecommendation\Rec\Code\value_counts1.xlsx', encoding='utf_8_sig', header=False, index=False)

# 诗诗写的 end
print('*'*70)










